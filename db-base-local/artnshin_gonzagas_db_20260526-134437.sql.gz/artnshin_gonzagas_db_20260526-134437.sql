/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.10-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: artnshin_gonzagas_db
-- ------------------------------------------------------
-- Server version	11.4.10-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activity_logs_user_id` (`user_id`),
  KEY `idx_activity_logs_entity` (`entity_type`,`entity_id`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de atividades dos usuários administrativos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Usuários com acesso à área administrativa';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES
(1,'admin','$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin@example.com','Administrador',1,NULL,'2025-05-22 10:02:30','2025-05-22 10:02:30');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `action` enum('data_access','consent_change','user_right_request','data_deletion','data_export','admin_access') NOT NULL,
  `resource` varchar(255) NOT NULL,
  `resource_id` varchar(255) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `consent_changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`consent_changes`)),
  `legal_basis` enum('consent','contract','legal_obligation','vital_interests','public_task','legitimate_interest') NOT NULL,
  `retention_period` enum('1 year','2 years','3 years','5 years','6 years') NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_action` (`action`),
  KEY `idx_resource` (`resource`),
  KEY `idx_legal_basis` (`legal_basis`),
  KEY `idx_retention_period` (`retention_period`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_action_created` (`action`,`created_at`),
  KEY `idx_session_created` (`session_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cookie_consents`
--

DROP TABLE IF EXISTS `cookie_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cookie_consents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL,
  `necessary` tinyint(1) DEFAULT 1,
  `analytics` tinyint(1) DEFAULT 0,
  `marketing` tinyint(1) DEFAULT 0,
  `preferences` tinyint(1) DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_session` (`session_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cookie_consents`
--

LOCK TABLES `cookie_consents` WRITE;
/*!40000 ALTER TABLE `cookie_consents` DISABLE KEYS */;
/*!40000 ALTER TABLE `cookie_consents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_transactions`
--

DROP TABLE IF EXISTS `inventory_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `transaction_type` enum('in','out','adjustment','purchase','sale') NOT NULL DEFAULT 'in',
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_transaction_type` (`transaction_type`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_transactions`
--

LOCK TABLES `inventory_transactions` WRITE;
/*!40000 ALTER TABLE `inventory_transactions` DISABLE KEYS */;
INSERT INTO `inventory_transactions` VALUES
(4,193,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:32:55'),
(5,194,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:33:11'),
(6,195,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:33:21'),
(7,196,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:46:30'),
(8,197,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:46:39'),
(9,198,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:48:14'),
(10,199,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:48:21'),
(11,200,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:48:29'),
(12,201,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:48:36'),
(13,202,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:49:11'),
(14,203,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:50:59'),
(15,204,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:51:05'),
(16,205,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:51:19'),
(17,206,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:51:26'),
(18,207,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 16:51:32'),
(19,208,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:30:00'),
(20,209,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:30:17'),
(21,210,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:31:15'),
(22,211,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:31:34'),
(23,212,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:32:36'),
(24,213,'in',4,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:33:02'),
(25,214,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:33:22'),
(26,215,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:34:23'),
(27,216,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:35:03'),
(28,217,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:36:47'),
(29,218,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:41:03'),
(30,219,'in',4,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:46:54'),
(31,220,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:47:28'),
(32,221,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:48:10'),
(33,222,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:48:33'),
(34,223,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:49:10'),
(35,224,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:49:50'),
(36,225,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 17:53:32'),
(37,226,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 18:37:20'),
(38,227,'in',4,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 18:41:05'),
(39,228,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:02:05'),
(40,229,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:07:02'),
(41,230,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:07:12'),
(42,231,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:07:53'),
(43,232,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:08:10'),
(44,233,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:08:36'),
(45,234,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:09:18'),
(46,235,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:10:32'),
(47,236,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:10:43'),
(48,237,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:11:03'),
(49,238,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:11:19'),
(50,239,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:14:44'),
(51,240,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:15:31'),
(52,241,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:15:51'),
(53,242,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:16:14'),
(54,243,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:16:31'),
(55,244,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:16:38'),
(56,245,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:17:07'),
(57,246,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:53:51'),
(58,247,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:54:11'),
(59,248,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:55:04'),
(60,249,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:55:23'),
(61,250,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:56:44'),
(62,251,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:57:22'),
(63,252,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:57:56'),
(64,253,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:59:04'),
(65,254,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:59:18'),
(66,255,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 19:59:36'),
(67,256,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:00:34'),
(68,257,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:00:45'),
(69,258,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:01:19'),
(70,259,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:01:32'),
(71,260,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:01:40'),
(72,261,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:02:02'),
(73,262,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:05:39'),
(74,263,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:05:51'),
(75,264,'in',3,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:06:04'),
(76,265,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:06:42'),
(77,266,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:07:14'),
(78,267,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:07:30'),
(79,268,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:08:23'),
(80,269,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:08:39'),
(81,270,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:09:47'),
(82,271,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:12:35'),
(83,272,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:25:21'),
(84,273,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:25:30'),
(85,274,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:50:38'),
(86,275,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:50:46'),
(87,276,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:51:04'),
(88,277,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:51:12'),
(89,278,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-19 20:51:22'),
(90,279,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-21 16:51:54'),
(91,280,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-21 17:09:32'),
(92,281,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-21 17:09:45'),
(93,282,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-21 17:10:28'),
(94,283,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-21 17:10:37'),
(95,284,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-21 17:10:47'),
(96,285,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-21 17:10:55'),
(97,286,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-02-21 17:11:33'),
(98,287,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-18 19:18:18'),
(99,288,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-18 19:33:56'),
(100,289,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-18 19:43:04'),
(101,290,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-18 19:51:40'),
(102,291,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-18 19:52:24'),
(103,292,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:08:10'),
(104,293,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:08:56'),
(105,294,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:09:11'),
(106,295,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:12:56'),
(107,296,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:15:10'),
(108,297,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:15:58'),
(109,298,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:16:31'),
(110,299,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:17:07'),
(112,301,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 14:19:29'),
(113,303,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 23:49:13'),
(114,304,'in',3,0.00,0.00,'Stock inicial do produto',4,'2026-03-31 23:51:48'),
(115,305,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:00:06'),
(116,306,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:08:12'),
(117,307,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:08:41'),
(118,308,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:09:01'),
(119,309,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:09:46'),
(120,310,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:10:10'),
(121,311,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:29:18'),
(122,312,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:29:36'),
(123,313,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:29:51'),
(124,314,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:30:09'),
(125,315,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:45:14'),
(126,316,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:46:00'),
(127,317,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:46:18'),
(128,318,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:46:37'),
(129,319,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:48:40'),
(130,320,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:49:27'),
(131,321,'in',3,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 00:50:33'),
(132,322,'in',4,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:23:58'),
(133,323,'in',4,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:32:39'),
(134,324,'in',3,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:33:22'),
(135,325,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:33:55'),
(136,326,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:34:37'),
(137,327,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:35:35'),
(138,328,'in',1,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:35:42'),
(139,329,'in',4,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:36:05'),
(140,330,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:36:59'),
(141,331,'in',4,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:37:19'),
(142,332,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:38:10'),
(143,333,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:38:26'),
(144,334,'in',2,0.00,0.00,'Stock inicial do produto',4,'2026-04-01 01:38:34');
/*!40000 ALTER TABLE `inventory_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_file_tags`
--

DROP TABLE IF EXISTS `media_file_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_file_tags` (
  `media_file_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`media_file_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `media_file_tags_ibfk_1` FOREIGN KEY (`media_file_id`) REFERENCES `media_files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_file_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `media_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_file_tags`
--

LOCK TABLES `media_file_tags` WRITE;
/*!40000 ALTER TABLE `media_file_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_file_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_files`
--

DROP TABLE IF EXISTS `media_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `original_filename` varchar(255) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `has_thumbnail` tinyint(1) DEFAULT 0,
  `has_medium` tinyint(1) DEFAULT 0,
  `has_large` tinyint(1) DEFAULT 0,
  `has_webp` tinyint(1) DEFAULT 0,
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `folder_path` varchar(500) DEFAULT '/',
  `original_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `alt_text` varchar(500) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `dominant_color` varchar(7) DEFAULT NULL,
  `dimensions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dimensions`)),
  `file_hash` varchar(64) DEFAULT NULL,
  `processed_variants` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`processed_variants`)),
  `upload_source` varchar(50) DEFAULT 'web',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_filename` (`filename`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=275 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_files`
--

LOCK TABLES `media_files` WRITE;
/*!40000 ALTER TABLE `media_files` DISABLE KEYS */;
INSERT INTO `media_files` VALUES
(1,'WhatsApp Image 2025-02-22 at 18.50.15.jpeg',NULL,307098,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.15.jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.15.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(2,'WhatsApp Image 2025-02-22 at 18.50.16 (1).jpeg',NULL,377534,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.16 (1).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.16 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(3,'WhatsApp Image 2025-02-22 at 18.50.16.jpeg',NULL,774971,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.16.jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.16.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(4,'WhatsApp Image 2025-02-22 at 18.50.17 (1).jpeg',NULL,478960,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.17 (1).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.17 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(5,'WhatsApp Image 2025-02-22 at 18.50.17 (2).jpeg',NULL,454069,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.17 (2).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.17 (2).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(6,'WhatsApp Image 2025-02-22 at 18.50.17.jpeg',NULL,186433,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.17.jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.17.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(7,'WhatsApp Image 2025-02-22 at 18.50.18 (1).jpeg',NULL,360577,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.18 (1).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.18 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(8,'WhatsApp Image 2025-02-22 at 18.50.18 (2).jpeg',NULL,275856,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.18 (2).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.18 (2).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(9,'WhatsApp Image 2025-02-22 at 18.50.18.jpeg',NULL,313898,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.18.jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.18.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(10,'WhatsApp Image 2025-02-22 at 18.50.22 (1).jpeg',NULL,481194,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.22 (1).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.22 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(11,'WhatsApp Image 2025-02-22 at 18.50.22.jpeg',NULL,352338,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.22.jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.22.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(12,'WhatsApp Image 2025-02-22 at 18.50.23 (1).jpeg',NULL,658572,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.23 (1).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.23 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(13,'WhatsApp Image 2025-02-22 at 18.50.23 (2).jpeg',NULL,724689,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.23 (2).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.23 (2).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(14,'WhatsApp Image 2025-02-22 at 18.50.23 (3).jpeg',NULL,332126,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.23 (3).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.23 (3).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(15,'WhatsApp Image 2025-02-22 at 18.50.23 (4).jpeg',NULL,411142,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.23 (4).jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.23 (4).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(16,'WhatsApp Image 2025-02-22 at 18.50.23.jpeg',NULL,485053,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-02-22 at 18.50.23.jpeg','/media/WhatsApp Image 2025-02-22 at 18.50.23.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(17,'WhatsApp Image 2025-04-05 at 19.12.28_96f8209b.jpg',NULL,225326,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.28_96f8209b.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.28_96f8209b.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(18,'WhatsApp Image 2025-04-05 at 19.12.29_455cd87b.jpg',NULL,302526,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.29_455cd87b.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.29_455cd87b.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(19,'WhatsApp Image 2025-04-05 at 19.12.29_8100f363.jpg',NULL,228225,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.29_8100f363.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.29_8100f363.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(20,'WhatsApp Image 2025-04-05 at 19.12.30_3098b273.jpg',NULL,308149,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.30_3098b273.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.30_3098b273.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(21,'WhatsApp Image 2025-04-05 at 19.12.31_0d69289d.jpg',NULL,234374,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.31_0d69289d.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.31_0d69289d.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(22,'WhatsApp Image 2025-04-05 at 19.12.31_de78d05d.jpg',NULL,278477,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.31_de78d05d.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.31_de78d05d.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(23,'WhatsApp Image 2025-04-05 at 19.12.32_49337176.jpg',NULL,285240,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.32_49337176.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.32_49337176.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(24,'WhatsApp Image 2025-04-05 at 19.12.32_a477290e.jpg',NULL,269848,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.32_a477290e.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.32_a477290e.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(25,'WhatsApp Image 2025-04-05 at 19.12.32_ebf03bb5.jpg',NULL,271561,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.32_ebf03bb5.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.32_ebf03bb5.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(26,'WhatsApp Image 2025-04-05 at 19.12.33_6c5befd8.jpg',NULL,306120,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.33_6c5befd8.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.33_6c5befd8.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(27,'WhatsApp Image 2025-04-05 at 19.12.33_d99ce135.jpg',NULL,271885,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.33_d99ce135.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.33_d99ce135.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(28,'WhatsApp Image 2025-04-05 at 19.12.34_c595397c.jpg',NULL,266097,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.34_c595397c.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.34_c595397c.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(29,'WhatsApp Image 2025-04-05 at 19.12.35_aedbe7ef.jpg',NULL,259159,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.35_aedbe7ef.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.35_aedbe7ef.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(30,'WhatsApp Image 2025-04-05 at 19.12.35_d66093b5.jpg',NULL,295511,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.35_d66093b5.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.35_d66093b5.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(31,'WhatsApp Image 2025-04-05 at 19.12.36_65be0022.jpg',NULL,361418,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.36_65be0022.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.36_65be0022.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(32,'WhatsApp Image 2025-04-05 at 19.12.36_72f74cb5.jpg',NULL,263217,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.36_72f74cb5.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.36_72f74cb5.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(33,'WhatsApp Image 2025-04-05 at 19.12.36_db00e7b0.jpg',NULL,278192,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.36_db00e7b0.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.36_db00e7b0.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(34,'WhatsApp Image 2025-04-05 at 19.12.36_dbd671f8.jpg',NULL,335478,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.36_dbd671f8.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.36_dbd671f8.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(35,'WhatsApp Image 2025-04-05 at 19.12.37_275b39da.jpg',NULL,288492,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.37_275b39da.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_275b39da.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(36,'WhatsApp Image 2025-04-05 at 19.12.37_3ed95ad4.jpg',NULL,229035,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.37_3ed95ad4.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_3ed95ad4.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(37,'WhatsApp Image 2025-04-05 at 19.12.37_60bc59a0.jpg',NULL,245475,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.37_60bc59a0.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_60bc59a0.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(38,'WhatsApp Image 2025-04-05 at 19.12.37_6e8db1ab.jpg',NULL,293997,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.37_6e8db1ab.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_6e8db1ab.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(39,'WhatsApp Image 2025-04-05 at 19.12.37_7c5ecda6.jpg',NULL,288492,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:21','2026-02-12 18:22:21','/','WhatsApp Image 2025-04-05 at 19.12.37_7c5ecda6.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_7c5ecda6.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(40,'WhatsApp Image 2025-04-05 at 19.12.37_7db3b574.jpg',NULL,235187,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/','WhatsApp Image 2025-04-05 at 19.12.37_7db3b574.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_7db3b574.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(41,'WhatsApp Image 2025-04-05 at 19.12.37_c7e2e302.jpg',NULL,241860,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/','WhatsApp Image 2025-04-05 at 19.12.37_c7e2e302.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_c7e2e302.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(42,'WhatsApp Image 2025-04-05 at 19.12.37_cda6b626.jpg',NULL,284487,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/','WhatsApp Image 2025-04-05 at 19.12.37_cda6b626.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_cda6b626.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(43,'WhatsApp Image 2025-04-05 at 19.12.37_d51c3f9b.jpg',NULL,293997,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/','WhatsApp Image 2025-04-05 at 19.12.37_d51c3f9b.jpg','/media/WhatsApp Image 2025-04-05 at 19.12.37_d51c3f9b.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(44,'gallery/WhatsApp Image 2025-02-22 at 18.50.15.jpeg',NULL,307098,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.15.jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.15.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(45,'gallery/WhatsApp Image 2025-02-22 at 18.50.16 (1).jpeg',NULL,377534,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.16 (1).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.16 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(46,'gallery/WhatsApp Image 2025-02-22 at 18.50.16.jpeg',NULL,774971,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.16.jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.16.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(47,'gallery/WhatsApp Image 2025-02-22 at 18.50.17 (1).jpeg',NULL,478960,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.17 (1).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.17 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(48,'gallery/WhatsApp Image 2025-02-22 at 18.50.17 (2).jpeg',NULL,454069,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.17 (2).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.17 (2).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(49,'gallery/WhatsApp Image 2025-02-22 at 18.50.17.jpeg',NULL,186433,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.17.jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.17.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(50,'gallery/WhatsApp Image 2025-02-22 at 18.50.18 (1).jpeg',NULL,360577,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.18 (1).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.18 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(51,'gallery/WhatsApp Image 2025-02-22 at 18.50.18 (2).jpeg',NULL,275856,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.18 (2).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.18 (2).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(52,'gallery/WhatsApp Image 2025-02-22 at 18.50.18.jpeg',NULL,313898,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.18.jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.18.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(53,'gallery/WhatsApp Image 2025-02-22 at 18.50.22 (1).jpeg',NULL,481194,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.22 (1).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.22 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(54,'gallery/WhatsApp Image 2025-02-22 at 18.50.22.jpeg',NULL,352338,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.22.jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.22.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(55,'gallery/WhatsApp Image 2025-02-22 at 18.50.23 (1).jpeg',NULL,658572,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.23 (1).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.23 (1).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(56,'gallery/WhatsApp Image 2025-02-22 at 18.50.23 (2).jpeg',NULL,724689,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.23 (2).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.23 (2).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(57,'gallery/WhatsApp Image 2025-02-22 at 18.50.23 (3).jpeg',NULL,332126,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.23 (3).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.23 (3).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(58,'gallery/WhatsApp Image 2025-02-22 at 18.50.23 (4).jpeg',NULL,411142,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.23 (4).jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.23 (4).jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(59,'gallery/WhatsApp Image 2025-02-22 at 18.50.23.jpeg',NULL,485053,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-02-22 at 18.50.23.jpeg','/media/gallery/WhatsApp Image 2025-02-22 at 18.50.23.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(60,'gallery/WhatsApp Image 2025-04-05 at 19.12.28_96f8209b.jpg',NULL,225326,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.28_96f8209b.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.28_96f8209b.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(61,'gallery/WhatsApp Image 2025-04-05 at 19.12.29_455cd87b.jpg',NULL,302526,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.29_455cd87b.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.29_455cd87b.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(62,'gallery/WhatsApp Image 2025-04-05 at 19.12.29_8100f363.jpg',NULL,228225,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.29_8100f363.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.29_8100f363.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(63,'gallery/WhatsApp Image 2025-04-05 at 19.12.30_3098b273.jpg',NULL,308149,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.30_3098b273.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.30_3098b273.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(64,'gallery/WhatsApp Image 2025-04-05 at 19.12.31_0d69289d.jpg',NULL,234374,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.31_0d69289d.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.31_0d69289d.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(65,'gallery/WhatsApp Image 2025-04-05 at 19.12.31_de78d05d.jpg',NULL,278477,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.31_de78d05d.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.31_de78d05d.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(66,'gallery/WhatsApp Image 2025-04-05 at 19.12.32_49337176.jpg',NULL,285240,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.32_49337176.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.32_49337176.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(67,'gallery/WhatsApp Image 2025-04-05 at 19.12.32_a477290e.jpg',NULL,269848,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.32_a477290e.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.32_a477290e.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(68,'gallery/WhatsApp Image 2025-04-05 at 19.12.32_ebf03bb5.jpg',NULL,271561,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.32_ebf03bb5.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.32_ebf03bb5.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(69,'gallery/WhatsApp Image 2025-04-05 at 19.12.33_6c5befd8.jpg',NULL,306120,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.33_6c5befd8.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.33_6c5befd8.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(70,'gallery/WhatsApp Image 2025-04-05 at 19.12.33_d99ce135.jpg',NULL,271885,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.33_d99ce135.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.33_d99ce135.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(71,'gallery/WhatsApp Image 2025-04-05 at 19.12.34_c595397c.jpg',NULL,266097,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.34_c595397c.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.34_c595397c.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(72,'gallery/WhatsApp Image 2025-04-05 at 19.12.35_aedbe7ef.jpg',NULL,259159,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.35_aedbe7ef.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.35_aedbe7ef.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(73,'gallery/WhatsApp Image 2025-04-05 at 19.12.35_d66093b5.jpg',NULL,295511,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.35_d66093b5.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.35_d66093b5.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(74,'gallery/WhatsApp Image 2025-04-05 at 19.12.36_65be0022.jpg',NULL,361418,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.36_65be0022.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.36_65be0022.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(75,'gallery/WhatsApp Image 2025-04-05 at 19.12.36_72f74cb5.jpg',NULL,263217,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.36_72f74cb5.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.36_72f74cb5.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(76,'gallery/WhatsApp Image 2025-04-05 at 19.12.36_db00e7b0.jpg',NULL,278192,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.36_db00e7b0.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.36_db00e7b0.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(77,'gallery/WhatsApp Image 2025-04-05 at 19.12.36_dbd671f8.jpg',NULL,335478,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.36_dbd671f8.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.36_dbd671f8.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(78,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_275b39da.jpg',NULL,288492,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_275b39da.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_275b39da.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(79,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_3ed95ad4.jpg',NULL,229035,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_3ed95ad4.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_3ed95ad4.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(80,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_60bc59a0.jpg',NULL,245475,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_60bc59a0.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_60bc59a0.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(81,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_6e8db1ab.jpg',NULL,293997,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_6e8db1ab.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_6e8db1ab.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(82,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_7c5ecda6.jpg',NULL,288492,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_7c5ecda6.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_7c5ecda6.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(83,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_7db3b574.jpg',NULL,235187,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_7db3b574.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_7db3b574.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(84,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_c7e2e302.jpg',NULL,241860,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_c7e2e302.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_c7e2e302.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(85,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_cda6b626.jpg',NULL,284487,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_cda6b626.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_cda6b626.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(86,'gallery/WhatsApp Image 2025-04-05 at 19.12.37_d51c3f9b.jpg',NULL,293997,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/gallery/','WhatsApp Image 2025-04-05 at 19.12.37_d51c3f9b.jpg','/media/gallery/WhatsApp Image 2025-04-05 at 19.12.37_d51c3f9b.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(87,'products/PAN0001.jpg',NULL,81838,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/products/','PAN0001.jpg','/media/products/PAN0001.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(88,'products/PAN0002.jpg',NULL,82155,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/products/','PAN0002.jpg','/media/products/PAN0002.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(89,'products/PAN0003.jpg',NULL,77686,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/products/','PAN0003.jpg','/media/products/PAN0003.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(90,'products/PAN0004.jpg',NULL,80345,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/products/','PAN0004.jpg','/media/products/PAN0004.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(91,'products/PAN0005.jpg',NULL,78375,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:22','2026-02-12 18:22:22','/products/','PAN0005.jpg','/media/products/PAN0005.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(92,'products/PAN0006.jpg',NULL,68876,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0006.jpg','/media/products/PAN0006.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(93,'products/PAN0007.jpg',NULL,394700,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0007.jpg','/media/products/PAN0007.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(94,'products/PAN0008.jpg',NULL,65404,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0008.jpg','/media/products/PAN0008.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(95,'products/PAN0009.jpg',NULL,68109,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0009.jpg','/media/products/PAN0009.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(96,'products/PAN0010.jpg',NULL,90527,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0010.jpg','/media/products/PAN0010.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(97,'products/PAN0011.jpg',NULL,77441,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0011.jpg','/media/products/PAN0011.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(98,'products/PAN0012.jpg',NULL,78019,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0012.jpg','/media/products/PAN0012.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(99,'products/PAN0013.jpg',NULL,77572,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0013.jpg','/media/products/PAN0013.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(100,'products/PAN0014.jpg',NULL,73408,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0014.jpg','/media/products/PAN0014.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(101,'products/PAN0015.jpg',NULL,77457,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0015.jpg','/media/products/PAN0015.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(102,'products/PAN0016.jpg',NULL,68896,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0016.jpg','/media/products/PAN0016.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(103,'products/PAN0017.jpg',NULL,74487,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0017.jpg','/media/products/PAN0017.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(104,'products/PAN0018.jpg',NULL,71954,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0018.jpg','/media/products/PAN0018.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(105,'products/PAN0019.jpg',NULL,82291,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0019.jpg','/media/products/PAN0019.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(106,'products/PAN0020.jpg',NULL,82153,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0020.jpg','/media/products/PAN0020.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(107,'products/PAN0021.jpg',NULL,88623,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0021.jpg','/media/products/PAN0021.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(108,'products/PAN0022.jpg',NULL,71451,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0022.jpg','/media/products/PAN0022.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(109,'products/PAN0023.jpg',NULL,91927,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0023.jpg','/media/products/PAN0023.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(110,'products/PAN0024.jpg',NULL,90902,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0024.jpg','/media/products/PAN0024.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(111,'products/PAN0025.jpg',NULL,74400,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0025.jpg','/media/products/PAN0025.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(112,'products/PAN0026.jpg',NULL,78535,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0026.jpg','/media/products/PAN0026.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(113,'products/PAN0027.jpg',NULL,101915,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0027.jpg','/media/products/PAN0027.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(114,'products/PAN0028.jpg',NULL,83697,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0028.jpg','/media/products/PAN0028.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(115,'products/PAN0029.jpg',NULL,78359,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0029.jpg','/media/products/PAN0029.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(116,'products/PAN0030.jpg',NULL,29643,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0030.jpg','/media/products/PAN0030.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(117,'products/PAN0031.jpg',NULL,29643,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0031.jpg','/media/products/PAN0031.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(118,'products/PAN0032.jpg',NULL,34177,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0032.jpg','/media/products/PAN0032.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(119,'products/PAN0033.jpg',NULL,34965,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0033.jpg','/media/products/PAN0033.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(120,'products/PAN0034.jpg',NULL,31264,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0034.jpg','/media/products/PAN0034.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(121,'products/PAN0035.jpg',NULL,30678,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0035.jpg','/media/products/PAN0035.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(122,'products/PAN0036.jpg',NULL,27986,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0036.jpg','/media/products/PAN0036.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(123,'products/PAN0037.jpg',NULL,33506,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0037.jpg','/media/products/PAN0037.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(124,'products/PAN0038.jpg',NULL,31681,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0038.jpg','/media/products/PAN0038.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(125,'products/PAN0039.jpg',NULL,30157,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0039.jpg','/media/products/PAN0039.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(126,'products/PAN0040.jpg',NULL,33681,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0040.jpg','/media/products/PAN0040.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(127,'products/PAN0041.jpg',NULL,34907,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0041.jpg','/media/products/PAN0041.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(128,'products/PAN0042.jpg',NULL,38427,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0042.jpg','/media/products/PAN0042.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(129,'products/PAN0043.jpg',NULL,30776,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0043.jpg','/media/products/PAN0043.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(130,'products/PAN0044.jpg',NULL,31854,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0044.jpg','/media/products/PAN0044.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(131,'products/PAN0045.jpg',NULL,30337,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0045.jpg','/media/products/PAN0045.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(132,'products/PAN0046.jpg',NULL,35314,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0046.jpg','/media/products/PAN0046.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(133,'products/PAN0047.jpg',NULL,35937,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0047.jpg','/media/products/PAN0047.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(134,'products/PAN0048.jpg',NULL,37208,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0048.jpg','/media/products/PAN0048.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(135,'products/PAN0049.jpg',NULL,35262,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0049.jpg','/media/products/PAN0049.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(136,'products/PAN0050.jpg',NULL,33513,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0050.jpg','/media/products/PAN0050.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(137,'products/PAN0051.jpg',NULL,35661,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0051.jpg','/media/products/PAN0051.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(138,'products/PAN0052.jpg',NULL,33691,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0052.jpg','/media/products/PAN0052.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(139,'products/PAN0053.jpg',NULL,36890,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0053.jpg','/media/products/PAN0053.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(140,'products/PAN0054.jpg',NULL,35724,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0054.jpg','/media/products/PAN0054.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(141,'products/PAN0055.jpg',NULL,33973,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0055.jpg','/media/products/PAN0055.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(142,'products/PAN0056.jpg',NULL,39053,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0056.jpg','/media/products/PAN0056.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(143,'products/PAN0057.jpg',NULL,38316,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0057.jpg','/media/products/PAN0057.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(144,'products/PAN0058.jpg',NULL,35545,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0058.jpg','/media/products/PAN0058.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(145,'products/PAN0059.jpg',NULL,39804,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:23','2026-02-12 18:22:23','/products/','PAN0059.jpg','/media/products/PAN0059.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(146,'products/PAN0060.jpg',NULL,35581,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0060.jpg','/media/products/PAN0060.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(147,'products/PAN0061.jpg',NULL,41634,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0061.jpg','/media/products/PAN0061.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(148,'products/PAN0062.jpg',NULL,39472,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0062.jpg','/media/products/PAN0062.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(149,'products/PAN0063.jpg',NULL,37994,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0063.jpg','/media/products/PAN0063.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(150,'products/PAN0064.jpg',NULL,41427,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0064.jpg','/media/products/PAN0064.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(151,'products/PAN0065.jpg',NULL,38539,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0065.jpg','/media/products/PAN0065.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(152,'products/PAN0066.jpg',NULL,49891,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0066.jpg','/media/products/PAN0066.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(153,'products/PAN0067.jpg',NULL,45786,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0067.jpg','/media/products/PAN0067.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(154,'products/PAN0068.jpg',NULL,47058,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0068.jpg','/media/products/PAN0068.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(155,'products/PAN0069.jpg',NULL,33919,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0069.jpg','/media/products/PAN0069.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(156,'products/PAN0070.jpg',NULL,37378,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0070.jpg','/media/products/PAN0070.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(157,'products/PAN0071.jpg',NULL,37430,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0071.jpg','/media/products/PAN0071.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(158,'products/PAN0072.jpg',NULL,28688,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0072.jpg','/media/products/PAN0072.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(159,'products/PAN0073.jpg',NULL,28450,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0073.jpg','/media/products/PAN0073.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(160,'products/PAN0074.jpg',NULL,77457,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0074.jpg','/media/products/PAN0074.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(161,'products/PAN0075.jpg',NULL,92527,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PAN0075.jpg','/media/products/PAN0075.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(162,'products/PPB0001.jpg',NULL,66843,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0001.jpg','/media/products/PPB0001.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(163,'products/PPB0002.jpg',NULL,58524,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0002.jpg','/media/products/PPB0002.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(164,'products/PPB0003.jpg',NULL,90959,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0003.jpg','/media/products/PPB0003.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(165,'products/PPB0004.jpg',NULL,69229,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0004.jpg','/media/products/PPB0004.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(166,'products/PPB0005.jpg',NULL,67749,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0005.jpg','/media/products/PPB0005.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(167,'products/PPB0006.jpg',NULL,63838,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0006.jpg','/media/products/PPB0006.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(168,'products/PPB0007.jpg',NULL,63367,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0007.jpg','/media/products/PPB0007.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(169,'products/PPB0008.jpg',NULL,71568,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0008.jpg','/media/products/PPB0008.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(170,'products/PPB0009.jpg',NULL,75189,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0009.jpg','/media/products/PPB0009.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(171,'products/PPB0010.jpg',NULL,69190,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0010.jpg','/media/products/PPB0010.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(172,'products/PPB0011.jpg',NULL,73991,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0011.jpg','/media/products/PPB0011.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(173,'products/PPB0012.jpg',NULL,72807,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0012.jpg','/media/products/PPB0012.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(174,'products/PPB0013.jpg',NULL,80272,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0013.jpg','/media/products/PPB0013.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(175,'products/PPB0014.jpg',NULL,85064,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0014.jpg','/media/products/PPB0014.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(176,'products/PPB0015.jpg',NULL,70362,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0015.jpg','/media/products/PPB0015.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(177,'products/PPB0016.jpg',NULL,89149,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0016.jpg','/media/products/PPB0016.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(178,'products/PPB0017.jpg',NULL,100952,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0017.jpg','/media/products/PPB0017.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(179,'products/PPB0018.jpg',NULL,101226,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0018.jpg','/media/products/PPB0018.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(180,'products/PPB0019.jpg',NULL,92527,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0019.jpg','/media/products/PPB0019.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(181,'products/PPB0020.jpg',NULL,87630,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0020.jpg','/media/products/PPB0020.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(182,'products/PPB0021.jpg',NULL,79194,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0021.jpg','/media/products/PPB0021.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(183,'products/PPB0022.jpg',NULL,73090,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0022.jpg','/media/products/PPB0022.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(184,'products/PPB0023.jpg',NULL,63803,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0023.jpg','/media/products/PPB0023.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(185,'products/PPB0024.jpg',NULL,102115,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0024.jpg','/media/products/PPB0024.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(186,'products/PPB0025.jpg',NULL,72643,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0025.jpg','/media/products/PPB0025.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(187,'products/PPB0026.jpg',NULL,37406,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0026.jpg','/media/products/PPB0026.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(188,'products/PPB0027.jpg',NULL,51338,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0027.jpg','/media/products/PPB0027.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(189,'products/PPB0028.jpg',NULL,42253,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0028.jpg','/media/products/PPB0028.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(190,'products/PPB0029.jpg',NULL,40968,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0029.jpg','/media/products/PPB0029.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(191,'products/PPB0030.jpg',NULL,41829,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0030.jpg','/media/products/PPB0030.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(192,'products/PPB0031.jpg',NULL,39027,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0031.jpg','/media/products/PPB0031.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(193,'products/PPB0032.jpg',NULL,36148,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0032.jpg','/media/products/PPB0032.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(194,'products/PPB0033.jpg',NULL,37238,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPB0033.jpg','/media/products/PPB0033.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(195,'products/PPU0000.jpg',NULL,102754,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPU0000.jpg','/media/products/PPU0000.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(196,'products/PPU0001.jpg',NULL,172561,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPU0001.jpg','/media/products/PPU0001.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(197,'products/PPU0002.jpg',NULL,138808,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPU0002.jpg','/media/products/PPU0002.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(198,'products/PPU0003.jpg',NULL,114534,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:24','2026-02-12 18:22:24','/products/','PPU0003.jpg','/media/products/PPU0003.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(199,'products/PPU0004.jpg',NULL,140850,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0004.jpg','/media/products/PPU0004.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(200,'products/PPU0005.jpg',NULL,161328,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0005.jpg','/media/products/PPU0005.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(201,'products/PPU0006.jpg',NULL,109418,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0006.jpg','/media/products/PPU0006.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(202,'products/PPU0007.jpg',NULL,124151,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0007.jpg','/media/products/PPU0007.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(203,'products/PPU0008.jpg',NULL,137236,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0008.jpg','/media/products/PPU0008.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(204,'products/PPU0009.jpg',NULL,139283,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0009.jpg','/media/products/PPU0009.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(205,'products/PPU0010.jpg',NULL,93513,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0010.jpg','/media/products/PPU0010.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(206,'products/PPU0011.jpg',NULL,139554,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0011.jpg','/media/products/PPU0011.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(207,'products/PPU0012.jpg',NULL,202660,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0012.jpg','/media/products/PPU0012.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(208,'products/PPU0013.jpg',NULL,187802,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0013.jpg','/media/products/PPU0013.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(209,'products/PPU0014.jpg',NULL,121094,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0014.jpg','/media/products/PPU0014.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(210,'products/PPU0015.jpg',NULL,98245,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0015.jpg','/media/products/PPU0015.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(211,'products/PPU0016.jpg',NULL,115705,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0016.jpg','/media/products/PPU0016.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(212,'products/PPU0017.jpg',NULL,112652,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0017.jpg','/media/products/PPU0017.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(213,'products/PPU0018.jpg',NULL,130230,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0018.jpg','/media/products/PPU0018.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(214,'products/PPU0019.jpg',NULL,114180,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0019.jpg','/media/products/PPU0019.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(215,'products/PPU0020.jpg',NULL,138617,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0020.jpg','/media/products/PPU0020.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(216,'products/PPU0021.jpg',NULL,78043,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0021.jpg','/media/products/PPU0021.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(217,'products/PPU0022.jpg',NULL,75489,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0022.jpg','/media/products/PPU0022.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(218,'products/PPU0023.jpg',NULL,141818,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0023.jpg','/media/products/PPU0023.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(219,'products/PPU0024.jpg',NULL,122633,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0024.jpg','/media/products/PPU0024.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(220,'products/PPU0025.jpg',NULL,140257,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0025.jpg','/media/products/PPU0025.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(221,'products/PPU0026.jpg',NULL,114737,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0026.jpg','/media/products/PPU0026.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(222,'products/PPU0027.jpg',NULL,100416,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0027.jpg','/media/products/PPU0027.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(223,'products/PPU0028.jpg',NULL,512540,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0028.jpg','/media/products/PPU0028.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(224,'products/PPU0029.jpg',NULL,507896,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0029.jpg','/media/products/PPU0029.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(225,'products/PPU0030.jpg',NULL,512426,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0030.jpg','/media/products/PPU0030.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(226,'products/PPU0031.jpg',NULL,386140,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0031.jpg','/media/products/PPU0031.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(227,'products/PPU0032.jpg',NULL,471815,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0032.jpg','/media/products/PPU0032.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(228,'products/PPU0033.jpg',NULL,563275,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0033.jpg','/media/products/PPU0033.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(229,'products/PPU0034.jpg',NULL,463584,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0034.jpg','/media/products/PPU0034.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(230,'products/PPU0035.jpg',NULL,511432,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0035.jpg','/media/products/PPU0035.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(231,'products/PPU0036.jpg',NULL,416982,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0036.jpg','/media/products/PPU0036.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(232,'products/PPU0037.jpg',NULL,517467,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0037.jpg','/media/products/PPU0037.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(233,'products/PPU0038.jpg',NULL,500859,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0038.jpg','/media/products/PPU0038.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(234,'products/PPU0039.jpg',NULL,410538,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0039.jpg','/media/products/PPU0039.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(235,'products/PPU0040.jpg',NULL,423197,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0040.jpg','/media/products/PPU0040.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(236,'products/PPU0041.jpg',NULL,414996,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0041.jpg','/media/products/PPU0041.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(237,'products/PPU0042.jpg',NULL,427706,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0042.jpg','/media/products/PPU0042.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(238,'products/PPU0043.jpg',NULL,402146,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0043.jpg','/media/products/PPU0043.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(239,'products/PPU0044.jpg',NULL,464147,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0044.jpg','/media/products/PPU0044.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(240,'products/PPU0045.jpg',NULL,274737,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0045.jpg','/media/products/PPU0045.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(241,'products/PPU0046.jpg',NULL,410806,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0046.jpg','/media/products/PPU0046.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(242,'products/PPU0047.jpg',NULL,473172,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0047.jpg','/media/products/PPU0047.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(243,'products/PPU0048.jpg',NULL,407944,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0048.jpg','/media/products/PPU0048.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(244,'products/PPU0049.jpg',NULL,421615,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0049.jpg','/media/products/PPU0049.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(245,'products/PPU0050.jpg',NULL,427068,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0050.jpg','/media/products/PPU0050.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(246,'products/PPU0051.jpg',NULL,442894,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0051.jpg','/media/products/PPU0051.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(247,'products/PPU0052.jpg',NULL,547307,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0052.jpg','/media/products/PPU0052.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(248,'products/PPU0053.jpg',NULL,400383,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0053.jpg','/media/products/PPU0053.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(249,'products/PPU0054.jpg',NULL,452662,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0054.jpg','/media/products/PPU0054.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(250,'products/PPU0055.jpg',NULL,414146,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:25','2026-02-12 18:22:25','/products/','PPU0055.jpg','/media/products/PPU0055.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(251,'products/PPU0056.jpg',NULL,384663,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0056.jpg','/media/products/PPU0056.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(252,'products/PPU0057.jpg',NULL,477882,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0057.jpg','/media/products/PPU0057.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(253,'products/PPU0058.jpg',NULL,498287,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0058.jpg','/media/products/PPU0058.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(254,'products/PPU0059.jpg',NULL,44952,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0059.jpg','/media/products/PPU0059.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(255,'products/PPU0060.jpg',NULL,39085,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0060.jpg','/media/products/PPU0060.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(256,'products/PPU0061.jpg',NULL,34561,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0061.jpg','/media/products/PPU0061.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(257,'products/PPU0062.jpg',NULL,36531,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0062.jpg','/media/products/PPU0062.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(258,'products/PPU0063.jpg',NULL,38672,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0063.jpg','/media/products/PPU0063.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(259,'products/PPU0064.jpg',NULL,36224,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0064.jpg','/media/products/PPU0064.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(260,'products/PPU0065.jpg',NULL,38105,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0065.jpg','/media/products/PPU0065.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(261,'products/PPU0066.jpg',NULL,34561,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0066.jpg','/media/products/PPU0066.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(262,'products/PPU0067.jpg',NULL,36492,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0067.jpg','/media/products/PPU0067.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(263,'products/PPU0068.jpg',NULL,38437,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0068.jpg','/media/products/PPU0068.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(264,'products/PPU0069.jpg',NULL,42579,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0069.jpg','/media/products/PPU0069.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(265,'products/PPU0070.jpg',NULL,37601,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0070.jpg','/media/products/PPU0070.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(266,'products/PPU0071.jpg',NULL,41501,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PPU0071.jpg','/media/products/PPU0071.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(267,'products/PVO0001.jpg',NULL,29039,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PVO0001.jpg','/media/products/PVO0001.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(268,'products/PVO0002.jpg',NULL,30281,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PVO0002.jpg','/media/products/PVO0002.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(269,'products/PVO0003.jpg',NULL,33845,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PVO0003.jpg','/media/products/PVO0003.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(270,'products/PVO0004.jpg',NULL,33840,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PVO0004.jpg','/media/products/PVO0004.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(271,'products/PVO0005.jpg',NULL,35355,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PVO0005.jpg','/media/products/PVO0005.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(272,'products/PVO0006.jpg',NULL,32865,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PVO0006.jpg','/media/products/PVO0006.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(273,'products/PVO0007.jpg',NULL,38119,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PVO0007.jpg','/media/products/PVO0007.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web'),
(274,'products/PVO0008.jpg',NULL,37833,'image/jpeg',NULL,NULL,0,0,0,0,NULL,'2026-02-12 18:22:26','2026-02-12 18:22:26','/products/','PVO0008.jpg','/media/products/PVO0008.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'web');
/*!40000 ALTER TABLE `media_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_folders`
--

DROP TABLE IF EXISTS `media_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `path` varchar(500) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(7) DEFAULT '#667eea',
  `icon` varchar(50) DEFAULT 'folder',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `path` (`path`),
  KEY `idx_path` (`path`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_folders`
--

LOCK TABLES `media_folders` WRITE;
/*!40000 ALTER TABLE `media_folders` DISABLE KEYS */;
INSERT INTO `media_folders` VALUES
(1,'Root','/',NULL,'Pasta principal','#667eea','folder','2026-02-12 17:41:41','2026-02-12 17:41:41'),
(2,'Products','/products/',NULL,'Imagens de produtos','#c0a080','gem','2026-02-12 17:41:41','2026-02-12 17:41:41'),
(3,'Categories','/categories/',NULL,'Imagens de categorias','#4ecdc4','tags','2026-02-12 17:41:41','2026-02-12 17:41:41'),
(4,'Blog','/blog/',NULL,'Imagens para blog','#f59e0b','edit','2026-02-12 17:41:41','2026-02-12 17:41:41'),
(5,'Marketing','/marketing/',NULL,'Material de marketing','#ef4444','bullhorn','2026-02-12 17:41:41','2026-02-12 17:41:41'),
(6,'Temp','/temp/',NULL,'Ficheiros temporários','#9ca3af','clock','2026-02-12 17:41:41','2026-02-12 17:41:41'),
(7,'Gallery','/gallery/',NULL,'Galeria do frontend','#4ecdc4','images','2026-02-12 18:22:21','2026-02-12 18:22:21');
/*!40000 ALTER TABLE `media_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_tags`
--

DROP TABLE IF EXISTS `media_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `color` varchar(7) DEFAULT '#c0a080',
  `usage_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_tags`
--

LOCK TABLES `media_tags` WRITE;
/*!40000 ALTER TABLE `media_tags` DISABLE KEYS */;
INSERT INTO `media_tags` VALUES
(1,'Produto','produto','#c0a080',0,'2026-02-12 17:41:41'),
(2,'Destaque','destaque','#f59e0b',0,'2026-02-12 17:41:41'),
(3,'Categoria','categoria','#4ecdc4',0,'2026-02-12 17:41:41'),
(4,'Marketing','marketing','#ef4444',0,'2026-02-12 17:41:41'),
(5,'Blog','blog','#8b5cf6',0,'2026-02-12 17:41:41'),
(6,'Temporário','temporario','#9ca3af',0,'2026-02-12 17:41:41');
/*!40000 ALTER TABLE `media_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_usage`
--

DROP TABLE IF EXISTS `media_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_usage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `media_id` int(11) NOT NULL,
  `used_in_table` varchar(100) NOT NULL,
  `used_in_id` int(11) NOT NULL,
  `usage_type` varchar(50) DEFAULT NULL,
  `usage_context` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_media_id` (`media_id`),
  CONSTRAINT `media_usage_ibfk_1` FOREIGN KEY (`media_id`) REFERENCES `media_files` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_usage`
--

LOCK TABLES `media_usage` WRITE;
/*!40000 ALTER TABLE `media_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_colors`
--

DROP TABLE IF EXISTS `product_colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `hex_code` varchar(7) DEFAULT NULL COMMENT 'CÃ³digo hex ex: #C0C0C0',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_colors`
--

LOCK TABLES `product_colors` WRITE;
/*!40000 ALTER TABLE `product_colors` DISABLE KEYS */;
INSERT INTO `product_colors` VALUES
(1,'Banho de Prata','#C0C0C0',1,1,'2026-02-11 19:34:26','2026-02-19 17:24:14'),
(2,'Dourado','#FFD700',2,1,'2026-02-11 19:34:26','2026-02-11 19:34:26'),
(3,'Prata oxidada','#A8A8A8',3,1,'2026-02-11 19:34:26','2026-02-11 19:34:26'),
(4,'Bronze','#CD7F32',4,1,'2026-02-11 19:34:26','2026-02-11 19:34:26'),
(5,'Cobre','#B87333',5,1,'2026-02-11 19:34:26','2026-02-11 19:34:26'),
(6,'Preto','#000000',6,1,'2026-02-11 19:34:26','2026-02-11 19:34:26'),
(7,'Outro',NULL,99,1,'2026-02-11 19:34:26','2026-02-11 19:34:26'),
(8,'Rose','#E8B4B8',3,1,'2026-02-12 11:59:28','2026-02-12 11:59:28');
/*!40000 ALTER TABLE `product_colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_families`
--

DROP TABLE IF EXISTS `product_families`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_families` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `parent_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `slug_unique_families` (`slug`),
  KEY `fk_product_families_parent` (`parent_id`),
  CONSTRAINT `fk_product_families_parent` FOREIGN KEY (`parent_id`) REFERENCES `product_families` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_families`
--

LOCK TABLES `product_families` WRITE;
/*!40000 ALTER TABLE `product_families` DISABLE KEYS */;
INSERT INTO `product_families` VALUES
(1,'PAN','Aneis - Prata',NULL,NULL,1,16,'2025-05-22 21:39:09','2026-02-19 16:08:20'),
(2,'PPB','Brincos - Prata',NULL,NULL,1,16,'2025-05-22 21:39:09','2026-02-19 16:08:28'),
(3,'PVO','Colares - Prata',NULL,NULL,1,16,'2025-05-22 21:39:09','2026-02-19 16:08:35'),
(4,'PPU','Pulseiras - Prata',NULL,NULL,1,16,'2025-05-22 21:39:09','2026-02-19 16:13:12'),
(5,'PN','Pedras Naturais',NULL,NULL,1,NULL,'2025-05-28 19:23:52','2026-02-19 15:07:06'),
(6,'LT','Latão',NULL,NULL,1,NULL,'2026-02-12 12:01:46','2026-02-12 12:16:04'),
(7,'LTG','Gargantilhas - Latão',NULL,NULL,1,6,'2026-02-12 12:03:33','2026-02-19 16:13:39'),
(8,'LTCU','Cuffs - Latão',NULL,NULL,1,6,'2026-02-12 12:05:10','2026-02-19 16:08:39'),
(9,'LTA','Aneis - Latão',NULL,NULL,1,6,'2026-02-19 11:58:01','2026-02-19 11:58:01'),
(10,'LTCL','Colares - Latão',NULL,NULL,1,6,'2026-02-19 11:59:30','2026-02-19 11:59:30'),
(11,'LTPD','Pendentes - Latão',NULL,NULL,1,6,'2026-02-19 11:59:59','2026-02-19 11:59:59'),
(12,'MC','Macramé',NULL,NULL,1,NULL,'2026-02-19 12:00:22','2026-02-19 12:00:22'),
(13,'MCCL','Colares - Macramé',NULL,NULL,1,12,'2026-02-19 12:00:48','2026-02-19 12:00:48'),
(14,'MCB','Brincos - Macramé',NULL,NULL,1,12,'2026-02-19 12:01:04','2026-02-19 12:01:04'),
(15,'LTB','Brincos - Latão',NULL,NULL,1,6,'2026-02-19 12:02:30','2026-02-19 12:02:30'),
(16,'P','Prata',NULL,NULL,1,NULL,'2026-02-19 12:02:48','2026-02-19 12:02:48'),
(17,'PPCF','Cuffs - Prata',NULL,NULL,1,16,'2026-02-19 12:06:51','2026-02-19 16:11:10'),
(18,'PNC','Colares - Pedras Naturais',NULL,NULL,1,5,'2026-02-19 15:06:54','2026-02-19 15:06:54'),
(19,'PNP','Pulseiras - Pedras Naturais',NULL,NULL,1,5,'2026-02-19 15:08:00','2026-02-19 15:08:00'),
(21,'PPD','Pendentes - Prata',NULL,NULL,1,16,'2026-02-19 16:13:05','2026-02-19 16:13:05'),
(22,'LTPC','Pentes de Cabelo - Latão',NULL,NULL,1,6,'2026-02-19 20:49:47','2026-02-19 20:49:47'),
(23,'LTPR','Piercings - Latão',NULL,NULL,1,6,'2026-02-21 16:22:35','2026-02-21 16:22:35'),
(24,'LTPRS','Piercings Sem Furo - Latão',NULL,NULL,1,6,'2026-02-21 16:23:15','2026-02-21 16:23:15'),
(25,'LTP','Pulseiras - Latão',NULL,NULL,1,6,'2026-03-31 14:11:32','2026-03-31 14:11:32');
/*!40000 ALTER TABLE `product_families` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_filename` varchar(255) NOT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=354 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
INSERT INTO `product_images` VALUES
(1,1,'PAN0001.jpg',1,0,'2025-05-22 20:50:25'),
(2,2,'PAN0002.jpg',1,0,'2025-05-22 20:50:25'),
(3,3,'PAN0003.jpg',1,0,'2025-05-22 20:50:25'),
(4,4,'PAN0004.jpg',1,0,'2025-05-22 20:50:25'),
(5,5,'PAN0005.jpg',1,0,'2025-05-22 20:50:25'),
(6,6,'PAN0006.jpg',1,0,'2025-05-22 20:50:25'),
(7,7,'PAN0007.jpg',1,0,'2025-05-22 20:50:25'),
(8,8,'PAN0008.jpg',1,0,'2025-05-22 20:50:25'),
(9,9,'PAN0009.jpg',1,0,'2025-05-22 20:50:25'),
(10,10,'PAN0010.jpg',1,0,'2025-05-22 20:50:25'),
(11,11,'PAN0011.jpg',1,0,'2025-05-22 20:50:25'),
(12,12,'PAN0012.jpg',1,0,'2025-05-22 20:50:25'),
(13,13,'PAN0013.jpg',1,0,'2025-05-22 20:50:25'),
(14,14,'PAN0014.jpg',1,0,'2025-05-22 20:50:25'),
(15,15,'PAN0015.jpg',1,0,'2025-05-22 20:50:25'),
(16,16,'PAN0016.jpg',1,0,'2025-05-22 20:50:25'),
(17,17,'PAN0017.jpg',1,0,'2025-05-22 20:50:25'),
(18,18,'PAN0018.jpg',1,0,'2025-05-22 20:50:25'),
(19,19,'PAN0019.jpg',1,0,'2025-05-22 20:50:25'),
(20,20,'PAN0020.jpg',1,0,'2025-05-22 20:50:25'),
(21,21,'PAN0021.jpg',1,0,'2025-05-22 20:50:25'),
(22,22,'PAN0022.jpg',1,0,'2025-05-22 20:50:25'),
(23,23,'PAN0023.jpg',1,0,'2025-05-22 20:50:25'),
(24,24,'PAN0024.jpg',1,0,'2025-05-22 20:50:25'),
(25,25,'PAN0025.jpg',1,0,'2025-05-22 20:50:25'),
(26,26,'PAN0026.jpg',1,0,'2025-05-22 20:50:25'),
(27,27,'PAN0027.jpg',1,0,'2025-05-22 20:50:25'),
(28,28,'PAN0028.jpg',1,0,'2025-05-22 20:50:25'),
(29,29,'PAN0029.jpg',1,0,'2025-05-22 20:50:25'),
(30,30,'PAN0030.jpg',1,0,'2025-05-22 20:50:25'),
(31,31,'PAN0031.jpg',1,0,'2025-05-22 20:50:25'),
(32,32,'PAN0032.jpg',1,0,'2025-05-22 20:50:25'),
(33,33,'PAN0033.jpg',1,0,'2025-05-22 20:50:25'),
(34,34,'PAN0034.jpg',1,0,'2025-05-22 20:50:25'),
(35,35,'PAN0035.jpg',1,0,'2025-05-22 20:50:25'),
(36,36,'PAN0036.jpg',1,0,'2025-05-22 20:50:25'),
(37,37,'PAN0037.jpg',1,0,'2025-05-22 20:50:25'),
(38,38,'PAN0038.jpg',1,0,'2025-05-22 20:50:25'),
(39,39,'PAN0039.jpg',1,0,'2025-05-22 20:50:25'),
(40,40,'PAN0040.jpg',1,0,'2025-05-22 20:50:25'),
(41,41,'PAN0041.jpg',1,0,'2025-05-22 20:50:25'),
(42,42,'PAN0042.jpg',1,0,'2025-05-22 20:50:25'),
(43,43,'PAN0043.jpg',1,0,'2025-05-22 20:50:25'),
(44,44,'PAN0044.jpg',1,0,'2025-05-22 20:50:25'),
(45,45,'PAN0045.jpg',1,0,'2025-05-22 20:50:25'),
(46,46,'PAN0046.jpg',1,0,'2025-05-22 20:50:25'),
(47,47,'PAN0047.jpg',1,0,'2025-05-22 20:50:25'),
(48,48,'PAN0048.jpg',1,0,'2025-05-22 20:50:25'),
(49,49,'PAN0049.jpg',1,0,'2025-05-22 20:50:25'),
(50,50,'PAN0050.jpg',1,0,'2025-05-22 20:50:25'),
(51,51,'PAN0051.jpg',1,0,'2025-05-22 20:50:25'),
(52,52,'PAN0052.jpg',1,0,'2025-05-22 20:50:25'),
(53,53,'PAN0053.jpg',1,0,'2025-05-22 20:50:25'),
(54,54,'PAN0054.jpg',1,0,'2025-05-22 20:50:25'),
(55,55,'PAN0055.jpg',1,0,'2025-05-22 20:50:25'),
(56,56,'PAN0056.jpg',1,0,'2025-05-22 20:50:25'),
(57,57,'PAN0057.jpg',1,0,'2025-05-22 20:50:25'),
(58,58,'PAN0058.jpg',1,0,'2025-05-22 20:50:25'),
(59,59,'PAN0059.jpg',1,0,'2025-05-22 20:50:25'),
(60,60,'PAN0060.jpg',1,0,'2025-05-22 20:50:25'),
(61,61,'PAN0061.jpg',1,0,'2025-05-22 20:50:25'),
(62,62,'PAN0062.jpg',1,0,'2025-05-22 20:50:25'),
(63,63,'PAN0063.jpg',1,0,'2025-05-22 20:50:25'),
(64,64,'PAN0064.jpg',1,0,'2025-05-22 20:50:25'),
(65,65,'PAN0065.jpg',1,0,'2025-05-22 20:50:25'),
(66,66,'PAN0066.jpg',1,0,'2025-05-22 20:50:25'),
(67,67,'PAN0067.jpg',1,0,'2025-05-22 20:50:25'),
(68,68,'PAN0068.jpg',1,0,'2025-05-22 20:50:25'),
(69,69,'PAN0069.jpg',1,0,'2025-05-22 20:50:25'),
(70,70,'PAN0070.jpg',1,0,'2025-05-22 20:50:25'),
(71,71,'PAN0071.jpg',1,0,'2025-05-22 20:50:25'),
(72,72,'PAN0072.jpg',1,0,'2025-05-22 20:50:25'),
(73,73,'PAN0073.jpg',1,0,'2025-05-22 20:50:25'),
(74,74,'PAN0074.jpg',1,0,'2025-05-22 20:50:25'),
(75,75,'PAN0075.jpg',1,0,'2025-05-22 20:50:25'),
(76,76,'PPB0001.jpg',1,0,'2025-05-22 20:50:25'),
(77,77,'PPB0002.jpg',1,0,'2025-05-22 20:50:25'),
(78,78,'PPB0003.jpg',1,0,'2025-05-22 20:50:25'),
(79,79,'PPB0004.jpg',1,0,'2025-05-22 20:50:25'),
(80,80,'PPB0005.jpg',1,0,'2025-05-22 20:50:25'),
(81,81,'PPB0006.jpg',1,0,'2025-05-22 20:50:25'),
(82,82,'PPB0007.jpg',1,0,'2025-05-22 20:50:25'),
(83,83,'PPB0008.jpg',1,0,'2025-05-22 20:50:25'),
(84,84,'PPB0009.jpg',1,0,'2025-05-22 20:50:25'),
(85,85,'PPB0010.jpg',1,0,'2025-05-22 20:50:25'),
(86,86,'PPB0011.jpg',1,0,'2025-05-22 20:50:25'),
(87,87,'PPB0012.jpg',1,0,'2025-05-22 20:50:25'),
(88,88,'PPB0013.jpg',1,0,'2025-05-22 20:50:25'),
(89,89,'PPB0014.jpg',1,0,'2025-05-22 20:50:25'),
(90,90,'PPB0015.jpg',1,0,'2025-05-22 20:50:25'),
(91,91,'PPB0016.jpg',1,0,'2025-05-22 20:50:25'),
(92,92,'PPB0017.jpg',1,0,'2025-05-22 20:50:25'),
(93,93,'PPB0018.jpg',1,0,'2025-05-22 20:50:25'),
(94,94,'PPB0019.jpg',1,0,'2025-05-22 20:50:25'),
(95,95,'PPB0020.jpg',1,0,'2025-05-22 20:50:25'),
(96,96,'PPB0021.jpg',1,0,'2025-05-22 20:50:25'),
(97,97,'PPB0022.jpg',1,0,'2025-05-22 20:50:25'),
(98,98,'PPB0023.jpg',1,0,'2025-05-22 20:50:25'),
(99,99,'PPB0024.jpg',1,0,'2025-05-22 20:50:25'),
(100,100,'PPB0025.jpg',1,0,'2025-05-22 20:50:25'),
(101,101,'PPB0026.jpg',1,0,'2025-05-22 20:50:25'),
(102,102,'PPB0027.jpg',1,0,'2025-05-22 20:50:25'),
(103,103,'PPB0028.jpg',1,0,'2025-05-22 20:50:25'),
(104,104,'PPB0029.jpg',1,0,'2025-05-22 20:50:25'),
(105,105,'PPB0030.jpg',1,0,'2025-05-22 20:50:25'),
(106,106,'PPB0031.jpg',1,0,'2025-05-22 20:50:25'),
(107,107,'PPB0032.jpg',1,0,'2025-05-22 20:50:25'),
(108,108,'PPB0033.jpg',1,0,'2025-05-22 20:50:25'),
(109,109,'PPU0001.jpg',1,0,'2025-05-22 20:50:25'),
(110,110,'PPU0002.jpg',1,0,'2025-05-22 20:50:25'),
(111,111,'PPU0003.jpg',1,0,'2025-05-22 20:50:25'),
(112,112,'PPU0004.jpg',1,0,'2025-05-22 20:50:25'),
(113,113,'PPU0005.jpg',1,0,'2025-05-22 20:50:25'),
(114,114,'PPU0006.jpg',1,0,'2025-05-22 20:50:25'),
(115,115,'PPU0007.jpg',1,0,'2025-05-22 20:50:25'),
(116,116,'PPU0008.jpg',1,0,'2025-05-22 20:50:25'),
(117,117,'PPU0009.jpg',1,0,'2025-05-22 20:50:25'),
(118,118,'PPU0010.jpg',1,0,'2025-05-22 20:50:25'),
(119,119,'PPU0011.jpg',1,0,'2025-05-22 20:50:25'),
(120,120,'PPU0012.jpg',1,0,'2025-05-22 20:50:25'),
(121,121,'PPU0013.jpg',1,0,'2025-05-22 20:50:25'),
(122,122,'PPU0014.jpg',1,0,'2025-05-22 20:50:25'),
(123,123,'PPU0015.jpg',1,0,'2025-05-22 20:50:25'),
(124,124,'PPU0016.jpg',1,0,'2025-05-22 20:50:25'),
(125,125,'PPU0017.jpg',1,0,'2025-05-22 20:50:25'),
(126,126,'PPU0018.jpg',1,0,'2025-05-22 20:50:25'),
(127,127,'PPU0019.jpg',1,0,'2025-05-22 20:50:25'),
(128,128,'PPU0020.jpg',1,0,'2025-05-22 20:50:25'),
(129,129,'PPU0021.jpg',1,0,'2025-05-22 20:50:25'),
(130,130,'PPU0022.jpg',1,0,'2025-05-22 20:50:25'),
(131,131,'PPU0023.jpg',1,0,'2025-05-22 20:50:25'),
(132,132,'PPU0024.jpg',1,0,'2025-05-22 20:50:25'),
(133,133,'PPU0025.jpg',1,0,'2025-05-22 20:50:25'),
(134,134,'PPU0026.jpg',1,0,'2025-05-22 20:50:25'),
(135,135,'PPU0027.jpg',1,0,'2025-05-22 20:50:25'),
(136,136,'PVO0001.jpg',1,0,'2025-05-22 20:50:25'),
(137,137,'PPU0000.jpg',1,0,'2025-05-22 20:50:25'),
(138,138,'PPU0028.jpg',1,0,'2025-05-22 20:50:25'),
(139,139,'PPU0029.jpg',1,0,'2025-05-22 20:50:25'),
(140,140,'PPU0030.jpg',1,0,'2025-05-22 20:50:25'),
(141,141,'PPU0031.jpg',1,0,'2025-05-22 20:50:25'),
(142,142,'PPU0032.jpg',1,0,'2025-05-22 20:50:25'),
(143,143,'PPU0033.jpg',1,0,'2025-05-22 20:50:25'),
(144,144,'PPU0034.jpg',1,0,'2025-05-22 20:50:25'),
(145,145,'PPU0035.jpg',1,0,'2025-05-22 20:50:25'),
(146,146,'PPU0036.jpg',1,0,'2025-05-22 20:50:25'),
(147,147,'PPU0037.jpg',1,0,'2025-05-22 20:50:25'),
(148,148,'PPU0038.jpg',1,0,'2025-05-22 20:50:25'),
(149,149,'PPU0039.jpg',1,0,'2025-05-22 20:50:25'),
(150,150,'PPU0040.jpg',1,0,'2025-05-22 20:50:25'),
(151,151,'PPU0041.jpg',1,0,'2025-05-22 20:50:25'),
(152,152,'PPU0042.jpg',1,0,'2025-05-22 20:50:25'),
(153,153,'PPU0043.jpg',1,0,'2025-05-22 20:50:25'),
(154,154,'PPU0044.jpg',1,0,'2025-05-22 20:50:25'),
(155,155,'PPU0045.jpg',1,0,'2025-05-22 20:50:25'),
(156,156,'PPU0046.jpg',1,0,'2025-05-22 20:50:25'),
(157,157,'PPU0047.jpg',1,0,'2025-05-22 20:50:25'),
(158,158,'PPU0048.jpg',1,0,'2025-05-22 20:50:25'),
(159,159,'PPU0049.jpg',1,0,'2025-05-22 20:50:25'),
(160,160,'PPU0050.jpg',1,0,'2025-05-22 20:50:25'),
(161,161,'PPU0051.jpg',1,0,'2025-05-22 20:50:25'),
(162,162,'PPU0052.jpg',1,0,'2025-05-22 20:50:25'),
(163,163,'PPU0053.jpg',1,0,'2025-05-22 20:50:25'),
(164,164,'PPU0054.jpg',1,0,'2025-05-22 20:50:25'),
(165,165,'PPU0055.jpg',1,0,'2025-05-22 20:50:25'),
(166,166,'PPU0056.jpg',1,0,'2025-05-22 20:50:25'),
(167,167,'PPU0057.jpg',1,0,'2025-05-22 20:50:25'),
(168,168,'PPU0058.jpg',1,0,'2025-05-22 20:50:25'),
(169,169,'PPU0059.jpg',1,0,'2025-05-22 20:50:25'),
(170,170,'PPU0060.jpg',1,0,'2025-05-22 20:50:25'),
(171,171,'PPU0061.jpg',1,0,'2025-05-22 20:50:25'),
(172,172,'PPU0062.jpg',1,0,'2025-05-22 20:50:25'),
(173,173,'PPU0063.jpg',1,0,'2025-05-22 20:50:25'),
(174,174,'PPU0064.jpg',1,0,'2025-05-22 20:50:25'),
(175,175,'PPU0065.jpg',1,0,'2025-05-22 20:50:25'),
(176,176,'PPU0066.jpg',1,0,'2025-05-22 20:50:25'),
(177,177,'PPU0067.jpg',1,0,'2025-05-22 20:50:25'),
(178,178,'PPU0068.jpg',1,0,'2025-05-22 20:50:25'),
(179,179,'PPU0069.jpg',1,0,'2025-05-22 20:50:25'),
(180,180,'PPU0070.jpg',1,0,'2025-05-22 20:50:25'),
(181,181,'PPU0071.jpg',1,0,'2025-05-22 20:50:25'),
(182,182,'PVO0002.jpg',1,0,'2025-05-22 20:50:25'),
(183,183,'PVO0003.jpg',1,0,'2025-05-22 20:50:25'),
(184,184,'PVO0004.jpg',1,0,'2025-05-22 20:50:25'),
(185,185,'PVO0005.jpg',1,0,'2025-05-22 20:50:25'),
(186,186,'PVO0006.jpg',1,0,'2025-05-22 20:50:25'),
(187,187,'PVO0007.jpg',1,0,'2025-05-22 20:50:25'),
(188,188,'PVO0008.jpg',1,0,'2025-05-22 20:50:25'),
(194,193,'images-1771518775026-525460233.jpg',1,1,'2026-02-19 16:32:55'),
(195,194,'images-1771518791626-93133564.jpg',1,1,'2026-02-19 16:33:11'),
(196,195,'images-1771518801952-49606397.jpg',1,1,'2026-02-19 16:33:21'),
(197,196,'images-1771519590131-951099783.jpg',1,1,'2026-02-19 16:46:30'),
(198,197,'images-1771519599554-628591027.jpg',1,1,'2026-02-19 16:46:39'),
(199,198,'images-1771519694653-91706546.jpg',1,1,'2026-02-19 16:48:14'),
(200,199,'images-1771519701568-673669828.jpg',1,1,'2026-02-19 16:48:21'),
(201,200,'images-1771519709669-135369134.jpg',1,1,'2026-02-19 16:48:29'),
(202,201,'images-1771519716240-870092310.jpg',1,1,'2026-02-19 16:48:36'),
(203,202,'images-1771519751249-681337157.jpg',1,1,'2026-02-19 16:49:11'),
(204,203,'images-1771519859074-430489208.jpg',1,1,'2026-02-19 16:50:59'),
(205,204,'images-1771519865014-121694856.jpg',1,1,'2026-02-19 16:51:05'),
(206,205,'images-1771519879565-287620332.jpg',1,1,'2026-02-19 16:51:19'),
(207,206,'images-1771519886522-754581641.jpg',1,1,'2026-02-19 16:51:26'),
(208,207,'images-1771519892099-473432773.jpg',1,1,'2026-02-19 16:51:32'),
(209,208,'images-1771522200953-828304609.jpg',1,1,'2026-02-19 17:30:00'),
(210,209,'images-1771522217734-46894989.jpg',1,1,'2026-02-19 17:30:17'),
(211,210,'images-1771522275343-100699793.jpg',1,1,'2026-02-19 17:31:15'),
(212,211,'images-1771522294456-608332578.jpg',1,1,'2026-02-19 17:31:34'),
(213,212,'images-1771522356543-167258222.jpg',1,1,'2026-02-19 17:32:36'),
(214,213,'images-1771522382114-870198421.jpg',1,1,'2026-02-19 17:33:02'),
(215,214,'images-1771522402538-848743221.jpg',1,1,'2026-02-19 17:33:22'),
(216,215,'images-1771522463205-799929117.jpg',1,1,'2026-02-19 17:34:23'),
(217,216,'images-1771522503625-402857476.jpg',1,1,'2026-02-19 17:35:03'),
(218,217,'images-1771522607535-45375541.jpg',1,1,'2026-02-19 17:36:47'),
(219,218,'images-1771522863136-913375059.jpg',1,1,'2026-02-19 17:41:03'),
(220,219,'images-1771523214951-744538858.jpg',1,1,'2026-02-19 17:46:54'),
(221,220,'images-1771523248170-576843473.jpg',1,1,'2026-02-19 17:47:28'),
(222,221,'images-1771523290196-401020085.jpg',1,1,'2026-02-19 17:48:10'),
(223,222,'images-1771523313465-18047326.jpg',1,1,'2026-02-19 17:48:33'),
(224,223,'images-1771523350055-57076028.jpg',1,1,'2026-02-19 17:49:10'),
(225,224,'images-1771523390804-909117566.jpg',1,1,'2026-02-19 17:49:50'),
(226,225,'images-1771523612853-209777811.jpg',1,1,'2026-02-19 17:53:32'),
(227,226,'images-1771526239988-735088299.jpg',1,1,'2026-02-19 18:37:20'),
(229,228,'images-1771527725928-989485666.jpg',1,1,'2026-02-19 19:02:05'),
(230,229,'images-1771528022171-848713622.jpg',1,1,'2026-02-19 19:07:02'),
(231,230,'images-1771528032616-128843667.jpg',1,1,'2026-02-19 19:07:12'),
(232,231,'images-1771528073566-212678291.jpg',1,1,'2026-02-19 19:07:53'),
(233,232,'images-1771528089978-132630851.jpg',1,1,'2026-02-19 19:08:10'),
(234,233,'images-1771528116815-841620416.jpg',1,1,'2026-02-19 19:08:36'),
(235,234,'images-1771528158635-619044234.jpg',1,1,'2026-02-19 19:09:18'),
(236,235,'images-1771528232340-545534582.jpg',1,1,'2026-02-19 19:10:32'),
(237,236,'images-1771528243388-434318600.jpg',1,1,'2026-02-19 19:10:43'),
(238,237,'images-1771528263178-886267546.jpg',1,1,'2026-02-19 19:11:03'),
(239,238,'images-1771528279002-696450501.jpg',1,1,'2026-02-19 19:11:19'),
(240,239,'images-1771528484533-600103271.jpg',1,1,'2026-02-19 19:14:44'),
(241,240,'images-1771528531680-252374645.jpg',1,1,'2026-02-19 19:15:31'),
(242,241,'images-1771528551125-926107312.jpg',1,1,'2026-02-19 19:15:51'),
(243,242,'images-1771528574753-368942017.jpg',1,1,'2026-02-19 19:16:14'),
(244,243,'images-1771528591288-695784927.jpg',1,1,'2026-02-19 19:16:31'),
(245,244,'images-1771528598374-871692443.jpg',1,1,'2026-02-19 19:16:38'),
(246,245,'images-1771528627123-994486162.jpg',1,1,'2026-02-19 19:17:07'),
(247,246,'images-1771530831330-237107725.jpg',1,1,'2026-02-19 19:53:51'),
(248,247,'images-1771530851948-655761469.jpg',1,1,'2026-02-19 19:54:11'),
(249,248,'images-1771530904399-921069674.jpg',1,1,'2026-02-19 19:55:04'),
(250,249,'images-1771530923905-709993240.jpg',1,1,'2026-02-19 19:55:23'),
(251,250,'images-1771531004325-73053753.jpg',1,1,'2026-02-19 19:56:44'),
(252,251,'images-1771531042807-323432798.jpg',1,1,'2026-02-19 19:57:22'),
(253,252,'images-1771531076138-834909151.jpg',1,1,'2026-02-19 19:57:56'),
(254,253,'images-1771531144287-549729353.jpg',1,1,'2026-02-19 19:59:04'),
(255,254,'images-1771531158828-624331925.jpg',1,1,'2026-02-19 19:59:18'),
(256,255,'images-1771531176179-505284258.jpg',1,1,'2026-02-19 19:59:36'),
(257,256,'images-1771531234489-250793263.jpg',1,1,'2026-02-19 20:00:34'),
(258,257,'images-1771531245163-16159626.jpg',1,1,'2026-02-19 20:00:45'),
(259,258,'images-1771531278995-437956357.jpg',1,1,'2026-02-19 20:01:19'),
(260,259,'images-1771531292153-805156437.jpg',1,1,'2026-02-19 20:01:32'),
(262,261,'images-1771531322665-101326572.jpg',1,1,'2026-02-19 20:02:02'),
(263,260,'images-1771531482786-880754208.jpg',0,1,'2026-02-19 20:04:42'),
(264,262,'images-1771531539329-581562927.jpg',1,1,'2026-02-19 20:05:39'),
(265,263,'images-1771531551288-948921624.jpg',1,1,'2026-02-19 20:05:51'),
(266,264,'images-1771531564168-757299025.jpg',1,1,'2026-02-19 20:06:04'),
(267,265,'images-1771531602369-854843010.jpg',1,1,'2026-02-19 20:06:42'),
(268,266,'images-1771531634163-299162190.jpg',1,1,'2026-02-19 20:07:14'),
(269,267,'images-1771531650885-911293685.jpg',1,1,'2026-02-19 20:07:30'),
(270,268,'images-1771531703425-297261824.jpg',1,1,'2026-02-19 20:08:23'),
(271,269,'images-1771531719269-919821895.jpg',1,1,'2026-02-19 20:08:39'),
(272,270,'images-1771531787743-396124930.jpg',1,1,'2026-02-19 20:09:47'),
(273,271,'images-1771531955716-500498897.jpg',1,1,'2026-02-19 20:12:35'),
(274,272,'images-1771532721506-519995178.jpg',1,1,'2026-02-19 20:25:21'),
(275,273,'images-1771532730158-647182105.jpg',1,1,'2026-02-19 20:25:30'),
(276,227,'images-1771534116937-605280769.jpg',0,1,'2026-02-19 20:48:36'),
(277,274,'images-1771534238683-900299621.jpg',1,1,'2026-02-19 20:50:38'),
(278,275,'images-1771534246305-146666330.jpg',1,1,'2026-02-19 20:50:46'),
(279,276,'images-1771534264458-589130680.jpg',1,1,'2026-02-19 20:51:04'),
(280,277,'images-1771534271982-667984497.jpg',1,1,'2026-02-19 20:51:12'),
(281,278,'images-1771534282448-187116393.jpg',1,1,'2026-02-19 20:51:22'),
(282,279,'images-1771692714413-37179980.jpg',1,1,'2026-02-21 16:51:54'),
(283,280,'images-1771693772040-549358957.jpg',1,1,'2026-02-21 17:09:32'),
(284,281,'images-1771693785118-988706764.jpg',1,1,'2026-02-21 17:09:45'),
(285,282,'images-1771693828928-570025310.jpg',1,1,'2026-02-21 17:10:28'),
(286,283,'images-1771693837966-447318091.jpg',1,1,'2026-02-21 17:10:37'),
(287,284,'images-1771693847134-517850924.jpg',1,1,'2026-02-21 17:10:47'),
(288,285,'images-1771693855300-603376677.jpg',1,1,'2026-02-21 17:10:55'),
(289,286,'images-1771693893022-477722453.jpg',1,1,'2026-02-21 17:11:33'),
(291,287,'images-1773861841344-974646346.jpg',0,1,'2026-03-18 19:24:01'),
(292,288,'images-1773862436023-801335445.jpg',1,1,'2026-03-18 19:33:56'),
(293,289,'images-1773862984001-457148822.jpg',1,1,'2026-03-18 19:43:04'),
(294,290,'images-1773863500312-549605742.jpg',1,1,'2026-03-18 19:51:40'),
(295,291,'images-1773863544360-221576542.jpg',1,1,'2026-03-18 19:52:24'),
(296,292,'images-1774966090604-693253930.jpg',1,1,'2026-03-31 14:08:10'),
(297,293,'images-1774966136332-674002725.jpg',1,1,'2026-03-31 14:08:56'),
(298,294,'images-1774966151918-812323430.jpg',1,1,'2026-03-31 14:09:11'),
(299,295,'images-1774966376767-174512423.jpg',1,1,'2026-03-31 14:12:56'),
(300,296,'images-1774966510329-180965996.jpg',1,1,'2026-03-31 14:15:10'),
(301,297,'images-1774966557994-919670929.jpg',1,1,'2026-03-31 14:15:57'),
(302,298,'images-1774966591369-512622627.jpg',1,1,'2026-03-31 14:16:31'),
(303,298,'images-1774966591370-373389270.jpg',0,2,'2026-03-31 14:16:31'),
(304,299,'images-1774966627312-473192888.jpg',1,1,'2026-03-31 14:17:07'),
(305,299,'images-1774966627321-771431552.jpg',0,2,'2026-03-31 14:17:07'),
(306,299,'images-1774966627326-46569910.jpg',0,3,'2026-03-31 14:17:07'),
(309,301,'images-1774966769396-66422813.jpg',1,1,'2026-03-31 14:19:29'),
(310,301,'images-1774966769399-490271064.jpg',0,2,'2026-03-31 14:19:29'),
(311,301,'images-1774966769402-632006026.jpg',0,3,'2026-03-31 14:19:29'),
(312,303,'images-1775000953188-492380501.jpg',1,1,'2026-03-31 23:49:13'),
(313,304,'images-1775001108777-553528580.jpg',1,1,'2026-03-31 23:51:48'),
(314,305,'images-1775001606108-468127312.jpg',1,1,'2026-04-01 00:00:06'),
(315,305,'images-1775001606112-268442839.jpg',0,2,'2026-04-01 00:00:06'),
(316,306,'images-1775002092681-352506688.jpg',1,1,'2026-04-01 00:08:12'),
(317,307,'images-1775002121073-334112107.jpg',1,1,'2026-04-01 00:08:41'),
(318,308,'images-1775002141360-410394955.jpg',1,1,'2026-04-01 00:09:01'),
(319,308,'images-1775002141431-244244100.jpg',0,2,'2026-04-01 00:09:01'),
(320,308,'images-1775002141480-740885724.jpg',0,3,'2026-04-01 00:09:01'),
(321,309,'images-1775002186507-189097250.jpg',1,1,'2026-04-01 00:09:46'),
(322,309,'images-1775002186513-399576535.jpg',0,2,'2026-04-01 00:09:46'),
(323,310,'images-1775002210206-714904056.jpg',1,1,'2026-04-01 00:10:10'),
(324,310,'images-1775002210214-855687504.jpg',0,2,'2026-04-01 00:10:10'),
(325,311,'images-1775003358931-371728444.jpg',1,1,'2026-04-01 00:29:18'),
(326,312,'images-1775003376353-392379865.jpg',1,1,'2026-04-01 00:29:36'),
(327,313,'images-1775003391794-384783191.jpg',1,1,'2026-04-01 00:29:51'),
(328,314,'images-1775003409009-729143826.png',1,1,'2026-04-01 00:30:09'),
(329,314,'images-1775003409013-256264997.JPG',0,2,'2026-04-01 00:30:09'),
(330,314,'images-1775003409014-842950484.JPG',0,3,'2026-04-01 00:30:09'),
(331,315,'images-1775004314689-184031662.jpg',1,1,'2026-04-01 00:45:14'),
(332,316,'images-1775004360671-739509295.jpg',1,1,'2026-04-01 00:46:00'),
(333,317,'images-1775004378551-277357797.jpg',1,1,'2026-04-01 00:46:18'),
(334,318,'images-1775004397960-886122834.jpg',1,1,'2026-04-01 00:46:37'),
(335,319,'images-1775004520154-728526249.jpg',1,1,'2026-04-01 00:48:40'),
(336,320,'images-1775004567423-643236159.jpg',1,1,'2026-04-01 00:49:27'),
(337,321,'images-1775004633069-669123972.jpg',1,1,'2026-04-01 00:50:33'),
(338,322,'images-1775006638451-980761404.jpg',1,1,'2026-04-01 01:23:58'),
(339,322,'images-1775006638454-413973239.jpg',0,2,'2026-04-01 01:23:58'),
(340,323,'images-1775007159703-128992880.png',1,1,'2026-04-01 01:32:39'),
(341,323,'images-1775007159706-964591711.png',0,2,'2026-04-01 01:32:39'),
(342,324,'images-1775007202647-173002122.jpg',1,1,'2026-04-01 01:33:22'),
(343,325,'images-1775007235899-578066860.jpg',1,1,'2026-04-01 01:33:55'),
(344,326,'images-1775007277646-199795312.jpg',1,1,'2026-04-01 01:34:37'),
(345,327,'images-1775007335849-828970606.jpg',1,1,'2026-04-01 01:35:35'),
(346,328,'images-1775007342476-736367626.jpg',1,1,'2026-04-01 01:35:42'),
(347,329,'images-1775007365599-553143846.jpg',1,1,'2026-04-01 01:36:05'),
(348,330,'images-1775007419693-310393273.jpg',1,1,'2026-04-01 01:36:59'),
(349,331,'images-1775007439582-239206076.jpg',1,1,'2026-04-01 01:37:19'),
(350,331,'images-1775007439588-541452524.jpg',0,2,'2026-04-01 01:37:19'),
(351,331,'images-1775007439588-998789225.jpg',0,3,'2026-04-01 01:37:19'),
(352,332,'images-1775007490241-678763491.jpg',1,1,'2026-04-01 01:38:10'),
(353,334,'images-1775007514772-704133499.jpg',1,1,'2026-04-01 01:38:34');
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) NOT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `family_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `purchase_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `sale_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) DEFAULT 23.00 COMMENT 'IVA %%',
  `current_stock` int(11) DEFAULT 0,
  `last_stock_update` timestamp NULL DEFAULT NULL,
  `min_stock` int(11) DEFAULT 5,
  `weight` decimal(10,3) DEFAULT 0.000,
  `active` tinyint(1) DEFAULT 1,
  `weight_unit` enum('g','kg') DEFAULT 'g',
  `dimensions` varchar(50) DEFAULT NULL COMMENT 'LxAxP em mm',
  `style` varchar(100) DEFAULT NULL,
  `material` varchar(100) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Atributos chave-valor' CHECK (json_valid(`attributes`)),
  `is_active` tinyint(1) DEFAULT 1,
  `min_stock_level` int(11) DEFAULT 0,
  `max_stock_level` int(11) DEFAULT 0,
  `location` varchar(50) DEFAULT NULL COMMENT 'Localização no armazém',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `featured` tinyint(1) DEFAULT 0,
  `is_catalog_visible` tinyint(1) DEFAULT 1 COMMENT 'Whether the product is visible in the public catalog',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  UNIQUE KEY `slug_unique_products` (`slug`),
  KEY `family_id` (`family_id`),
  KEY `idx_products_created_by` (`created_by`),
  KEY `idx_products_updated_by` (`updated_by`),
  KEY `idx_products_reference` (`reference`),
  KEY `idx_products_name` (`name`),
  CONSTRAINT `fk_products_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_products_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `product_families` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Produtos disponíveis para venda';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,'PAN0001','PAN0001',1,'Produto PAN0001',NULL,'Produto PAN0001',5.18,15.00,23.00,0,NULL,5,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:41:25',1,4,NULL,0,1),
(2,'PAN0002','PAN0002',1,'Produto PAN0002',NULL,'Produto PAN0002 - PAN',5.18,15.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(3,'PAN0003','PAN0003',1,'Produto PAN0003',NULL,'Produto PAN0003 - PAN',5.18,15.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(4,'PAN0004','PAN0004',1,'Produto PAN0004',NULL,'Produto PAN0004 - PAN',5.18,15.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:41:45',1,4,NULL,1,1),
(5,'PAN0005','PAN0005',1,'Produto PAN0005',NULL,'Produto PAN0005 - PAN',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(6,'PAN0006','PAN0006',1,'Produto PAN0006',NULL,'Produto PAN0006 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:42:47',1,4,NULL,1,1),
(7,'PAN0007','PAN0007',1,'Produto PAN0007',NULL,'Produto PAN0007 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:43:11',1,4,NULL,0,1),
(8,'PAN0008','PAN0008',1,'Produto PAN0008',NULL,'Produto PAN0008 - PAN',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(9,'PAN0009','PAN0009',1,'Produto PAN0009',NULL,'Produto PAN0009 - PAN',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(10,'PAN0010','PAN0010',1,'Produto PAN0010',NULL,'Produto PAN0010 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:44:07',1,4,NULL,0,1),
(11,'PAN0011','PAN0011',1,'Produto PAN0011',NULL,'Produto PAN0011 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:44:27',1,4,NULL,0,1),
(12,'PAN0012','PAN0012',1,'Produto PAN0012',NULL,'Produto PAN0012 - PAN',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(13,'PAN0013','PAN0013',1,'Produto PAN0013',NULL,'Produto PAN0013 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:45:44',1,4,NULL,0,1),
(14,'PAN0014','PAN0014',1,'Produto PAN0014',NULL,'Produto PAN0014 - PAN',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(15,'PAN0015','PAN0015',1,'Produto PAN0015',NULL,'Produto PAN0015 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:46:17',1,4,NULL,0,1),
(16,'PAN0016','PAN0016',1,'Produto PAN0016',NULL,'Produto PAN0016 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(17,'PAN0017','PAN0017',1,'Produto PAN0017',NULL,'Produto PAN0017 - PAN',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(18,'PAN0018','PAN0018',1,'Produto PAN0018',NULL,'Produto PAN0018 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:47:02',1,4,NULL,0,1),
(19,'PAN0019','PAN0019',1,'Produto PAN0019',NULL,'Produto PAN0019 - PAN',15.53,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:47:14',1,4,NULL,0,1),
(20,'PAN0020','PAN0020',1,'Produto PAN0020',NULL,'Produto PAN0020 - PAN',15.53,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(21,'PAN0021','PAN0021',1,'Produto PAN0021',NULL,'Produto PAN0021 - PAN',15.53,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(22,'PAN0022','PAN0022',1,'Produto PAN0022',NULL,'Produto PAN0022 - PAN',15.53,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:47:44',1,4,NULL,0,1),
(23,'PAN0023','PAN0023',1,'Produto PAN0023',NULL,'Produto PAN0023 - PAN',15.53,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(24,'PAN0024','PAN0024',1,'Produto PAN0024',NULL,'Produto PAN0024 - PAN',15.53,45.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(25,'PAN0025','PAN0025',1,'Produto PAN0025',NULL,'Produto PAN0025 - PAN',15.53,45.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(26,'PAN0026','PAN0026',1,'Produto PAN0026',NULL,'Produto PAN0026 - PAN',7.77,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(27,'PAN0027','PAN0027',1,'Produto PAN0027',NULL,'Produto PAN0027 - PAN',15.53,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:48:03',1,4,NULL,0,1),
(28,'PAN0028','PAN0028',1,'Produto PAN0028',NULL,'Produto PAN0028 - PAN',15.53,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:48:11',1,4,NULL,0,1),
(29,'PAN0029','PAN0029',1,'Produto PAN0029',NULL,'Produto PAN0029 - PAN',15.53,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:48:22',1,4,NULL,0,1),
(30,'PAN0030','PAN0030',1,'Produto PAN0030',NULL,'Produto PAN0030 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(31,'PAN0031','PAN0031',1,'Produto PAN0031',NULL,'Produto PAN0031 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(32,'PAN0032','PAN0032',1,'Produto PAN0032',NULL,'Produto PAN0032 - PAN',0.00,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:49:08',1,4,NULL,0,1),
(33,'PAN0033','PAN0033',1,'Produto PAN0033',NULL,'Produto PAN0033 - PAN',0.00,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:49:20',1,4,NULL,0,1),
(34,'PAN0034','PAN0034',1,'Produto PAN0034',NULL,'Produto PAN0034 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(35,'PAN0035','PAN0035',1,'Produto PAN0035',NULL,'Produto PAN0035 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(36,'PAN0036','PAN0036',1,'Produto PAN0036',NULL,'Produto PAN0036 - PAN',0.00,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:49:57',1,4,NULL,0,1),
(37,'PAN0037','PAN0037',1,'Produto PAN0037',NULL,'Produto PAN0037 - PAN',0.00,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:50:19',1,4,NULL,0,1),
(38,'PAN0038','PAN0038',1,'Produto PAN0038',NULL,'Produto PAN0038 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(39,'PAN0039','PAN0039',1,'Produto PAN0039',NULL,'Produto PAN0039 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(40,'PAN0040','PAN0040',1,'Produto PAN0040',NULL,'Produto PAN0040 - PAN',0.00,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:50:50',1,4,NULL,0,1),
(41,'PAN0041','PAN0041',1,'Produto PAN0041',NULL,'Produto PAN0041 - PAN',0.00,25.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(42,'PAN0042','PAN0042',1,'Produto PAN0042',NULL,'Produto PAN0042 - PAN',0.00,30.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:51:17',1,4,NULL,0,1),
(43,'PAN0043','PAN0043',1,'Produto PAN0043',NULL,'Produto PAN0043 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(44,'PAN0044','PAN0044',1,'Produto PAN0044',NULL,'Produto PAN0044 - PAN',0.00,40.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(45,'PAN0045','PAN0045',1,'Produto PAN0045',NULL,'Produto PAN0045 - PAN',0.00,40.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(46,'PAN0046','PAN0046',1,'Produto PAN0046',NULL,'Produto PAN0046 - PAN',0.00,40.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:52:05',1,4,NULL,0,1),
(47,'PAN0047','PAN0047',1,'Produto PAN0047',NULL,'Produto PAN0047 - PAN',0.00,45.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(48,'PAN0048','PAN0048',1,'Produto PAN0048',NULL,'Produto PAN0048 - PAN',0.00,45.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(49,'PAN0049','PAN0049',1,'Produto PAN0049',NULL,'Produto PAN0049 - PAN',0.00,45.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(50,'PAN0050','PAN0050',1,'Produto PAN0050',NULL,'Produto PAN0050 - PAN',0.00,40.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:52:28',1,4,NULL,0,1),
(51,'PAN0051','PAN0051',1,'Produto PAN0051',NULL,'Produto PAN0051 - PAN',0.00,45.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(52,'PAN0052','PAN0052',1,'Produto PAN0052',NULL,'Produto PAN0052 - PAN',0.00,55.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(53,'PAN0053','PAN0053',1,'Produto PAN0053',NULL,'Produto PAN0053 - PAN',0.00,55.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(54,'PAN0054','PAN0054',1,'Produto PAN0054',NULL,'Produto PAN0054 - PAN',0.00,55.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(55,'PAN0055','PAN0055',1,'Produto PAN0055',NULL,'Produto PAN0055 - PAN',0.00,55.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:53:15',1,4,NULL,0,1),
(56,'PAN0056','PAN0056',1,'Produto PAN0056',NULL,'Produto PAN0056 - PAN',0.00,55.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(57,'PAN0057','PAN0057',1,'Produto PAN0057',NULL,'Produto PAN0057 - PAN',0.00,55.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(58,'PAN0058','PAN0058',1,'Produto PAN0058',NULL,'Produto PAN0058 - PAN',0.00,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:53:33',1,4,NULL,0,1),
(59,'PAN0059','PAN0059',1,'Produto PAN0059',NULL,'Produto PAN0059 - PAN',0.00,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(60,'PAN0060','PAN0060',1,'Produto PAN0060',NULL,'Produto PAN0060 - PAN',0.00,55.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(61,'PAN0061','PAN0061',1,'Produto PAN0061',NULL,'Produto PAN0061 - PAN',0.00,45.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(62,'PAN0062','PAN0062',1,'Produto PAN0062',NULL,'Produto PAN0062 - PAN',0.00,55.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(63,'PAN0063','PAN0063',1,'Produto PAN0063',NULL,'Produto PAN0063 - PAN',0.00,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:54:17',1,4,NULL,0,1),
(64,'PAN0064','PAN0064',1,'Produto PAN0064',NULL,'Produto PAN0064 - PAN',0.00,45.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(65,'PAN0065','PAN0065',1,'Produto PAN0065',NULL,'Produto PAN0065 - PAN',0.00,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(66,'PAN0066','PAN0066',1,'Produto PAN0066',NULL,'Produto PAN0066 - PAN',0.00,75.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:54:33',1,4,NULL,0,1),
(67,'PAN0067','PAN0067',1,'Produto PAN0067',NULL,'Produto PAN0067 - PAN',0.00,75.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(68,'PAN0068','PAN0068',1,'Produto PAN0068',NULL,'Produto PAN0068 - PAN',0.00,75.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(69,'PAN0069','PAN0069',1,'Produto PAN0069',NULL,'Produto PAN0069 - PAN',0.00,0.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:54:47',1,4,NULL,0,1),
(70,'PAN0070','PAN0070',1,'Produto PAN0070',NULL,'Produto PAN0070 - PAN',0.00,45.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(71,'PAN0071','PAN0071',1,'Produto PAN0071',NULL,'Produto PAN0071 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(72,'PAN0072','PAN0072',1,'Produto PAN0072',NULL,'Produto PAN0072 - PAN',0.00,40.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(73,'PAN0073','PAN0073',1,'Produto PAN0073',NULL,'Produto PAN0073 - PAN',0.00,25.00,23.00,1,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(74,'PAN0074','PAN0074',1,'Produto PAN0074',NULL,'Produto PAN0074 - PAN',0.00,30.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(75,'PAN0075','PAN0075',1,'Produto PAN0075',NULL,'Produto PAN0075 - PAN',0.00,40.00,23.00,0,NULL,0,0.000,1,'g','','PAN','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(76,'PPB0001','PPB0001',2,'Produto PPB0001',NULL,'Produto PPB0001 - PPB',5.18,15.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(77,'PPB0002','PPB0002',2,'Produto PPB0002',NULL,'Produto PPB0002 - PPB',5.18,15.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(78,'PPB0003','PPB0003',2,'Produto PPB0003',NULL,'Produto PPB0003 - PPB',5.18,15.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(79,'PPB0004','PPB0004',2,'Produto PPB0004',NULL,'Produto PPB0004 - PPB',5.18,15.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(80,'PPB0005','PPB0005',2,'Produto PPB0005',NULL,'Produto PPB0005 - PPB',5.18,15.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(81,'PPB0006','PPB0006',2,'Produto PPB0006',NULL,'Produto PPB0006 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(82,'PPB0007','PPB0007',2,'Produto PPB0007',NULL,'Produto PPB0007 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(83,'PPB0008','PPB0008',2,'Produto PPB0008',NULL,'Produto PPB0008 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(84,'PPB0009','PPB0009',2,'Produto PPB0009',NULL,'Produto PPB0009 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(85,'PPB0010','PPB0010',2,'Produto PPB0010',NULL,'Produto PPB0010 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(86,'PPB0011','PPB0011',2,'Produto PPB0011',NULL,'Produto PPB0011 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,4,NULL,0,1),
(87,'PPB0012','PPB0012',2,'Produto PPB0012',NULL,'Produto PPB0012 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(88,'PPB0013','PPB0013',2,'Produto PPB0013',NULL,'Produto PPB0013 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(89,'PPB0014','PPB0014',2,'Produto PPB0014',NULL,'Produto PPB0014 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(90,'PPB0015','PPB0015',2,'Produto PPB0015',NULL,'Produto PPB0015 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(91,'PPB0016','PPB0016',2,'Produto PPB0016',NULL,'Produto PPB0016 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(92,'PPB0017','PPB0017',2,'Produto PPB0017',NULL,'Produto PPB0017 - PPB',7.77,25.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(93,'PPB0018','PPB0018',2,'Produto PPB0018',NULL,'Produto PPB0018 - PPB',10.35,30.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(94,'PPB0019','PPB0019',2,'Produto PPB0019',NULL,'Produto PPB0019 - PPB',10.35,30.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(95,'PPB0020','PPB0020',2,'Produto PPB0020',NULL,'Produto PPB0020 - PPB',10.35,30.00,23.00,0,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(96,'PPB0021','PPB0021',2,'Produto PPB0021',NULL,'Produto PPB0021 - PPB',10.35,30.00,23.00,0,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:45:05',1,4,NULL,0,1),
(97,'PPB0022','PPB0022',2,'Produto PPB0022',NULL,'Produto PPB0022 - PPB',10.35,30.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(98,'PPB0023','PPB0023',2,'Produto PPB0023',NULL,'Produto PPB0023 - PPB',18.12,55.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(99,'PPB0024','PPB0024',2,'Produto PPB0024',NULL,'Produto PPB0024 - PPB',18.12,55.00,23.00,0,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(100,'PPB0025','PPB0025',2,'Produto PPB0025',NULL,'Produto PPB0025 - PPB',20.71,60.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(101,'PPB0026','PPB0026',2,'Produto PPB0026',NULL,'Produto PPB0026 - PPB',0.00,30.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(102,'PPB0027','PPB0027',2,'Produto PPB0027',NULL,'Produto PPB0027 - PPB',0.00,40.00,23.00,0,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:44:57',1,4,NULL,0,1),
(103,'PPB0028','PPB0028',2,'Produto PPB0028',NULL,'Produto PPB0028 - PPB',0.00,40.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(104,'PPB0029','PPB0029',2,'Produto PPB0029',NULL,'Produto PPB0029 - PPB',0.00,40.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(105,'PPB0030','PPB0030',2,'Produto PPB0030',NULL,'Produto PPB0030 - PPB',0.00,40.00,23.00,0,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(106,'PPB0031','PPB0031',2,'Produto PPB0031',NULL,'Produto PPB0031 - PPB',0.00,45.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,4,NULL,0,1),
(107,'PPB0032','PPB0032',2,'Produto PPB0032',NULL,'Produto PPB0032 - PPB',0.00,55.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(108,'PPB0033','PPB0033',2,'Produto PPB0033',NULL,'Produto PPB0033 - PPB',0.00,60.00,23.00,1,NULL,0,0.000,1,'g','','PPB','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(109,'PPU0001','PPU0001',4,'Produto PPU0001',NULL,'Produto PPU0001 - PPU',93.18,225.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(110,'PPU0002','PPU0002',4,'Produto PPU0002',NULL,'Produto PPU0002 - PPU',93.18,225.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,4,NULL,0,1),
(111,'PPU0003','PPU0003',17,'Produto PPU0003',NULL,'Produto PPU0003 - PPU',28.47,70.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:00:26',1,4,NULL,0,1),
(112,'PPU0004','PPU0004',4,'Produto PPU0004',NULL,'Produto PPU0004 - PPU',98.36,240.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(113,'PPU0005','PPU0005',4,'Produto PPU0005',NULL,'Produto PPU0005 - PPU',20.71,50.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(114,'PPU0006','PPU0006',4,'Produto PPU0006',NULL,'Produto PPU0006 - PPU',62.12,175.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:59:05',1,4,NULL,0,1),
(115,'PPU0007','PPU0007',4,'Produto PPU0007',NULL,'Produto PPU0007 - PPU',67.30,165.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-16 12:53:29',1,4,NULL,1,1),
(116,'PPU0008','PPU0008',4,'Produto PPU0008',NULL,'Produto PPU0008 - PPU',23.30,45.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(117,'PPU0009','PPU0009',4,'Produto PPU0009',NULL,'Produto PPU0009 - PPU',10.35,25.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,4,NULL,1,1),
(118,'PPU0010','PPU0010',4,'Produto PPU0010',NULL,'Produto PPU0010 - PPU',15.53,40.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(119,'PPU0011','PPU0011',4,'Produto PPU0011',NULL,'Produto PPU0011 - PPU',20.71,40.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(120,'PPU0012','PPU0012',4,'Produto PPU0012',NULL,'Produto PPU0012 - PPU',20.71,45.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(121,'PPU0013','PPU0013',4,'Produto PPU0013',NULL,'Produto PPU0013 - PPU',18.12,45.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(122,'PPU0014','PPU0014',4,'Produto PPU0014',NULL,'Produto PPU0014 - PPU',28.47,70.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-03-16 13:49:13',1,4,NULL,0,1),
(123,'PPU0015','PPU0015',4,'Produto PPU0015',NULL,'Produto PPU0015 - PPU',20.71,50.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:59:34',1,4,NULL,0,1),
(124,'PPU0016','PPU0016',4,'Produto PPU0016',NULL,'Produto PPU0016 - PPU',38.83,75.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(125,'PPU0017','PPU0017',4,'Produto PPU0017',NULL,'Produto PPU0017 - PPU',31.06,75.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 12:59:47',1,4,NULL,0,1),
(126,'PPU0018','PPU0018',4,'Produto PPU0018',NULL,'Produto PPU0018 - PPU',62.12,165.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(127,'PPU0019','PPU0019',4,'Produto PPU0019',NULL,'Produto PPU0019 - PPU',31.06,75.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:40',1,1,NULL,0,1),
(128,'PPU0020','PPU0020',4,'Produto PPU0020',NULL,'Produto PPU0020 - PPU',31.06,75.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:00:03',1,4,NULL,0,1),
(129,'PPU0021','PPU0021',17,'Produto PPU0021',NULL,'Produto PPU0021 - PPU',20.71,50.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-03-16 13:46:48',1,4,NULL,0,1),
(130,'PPU0022','PPU0022',4,'Produto PPU0022',NULL,'Produto PPU0022 - PPU',10.35,25.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(131,'PPU0023','PPU0023',17,'Produto PPU0023',NULL,'Produto PPU0023 - PPU',18.12,45.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:01:24',1,4,NULL,0,1),
(132,'PPU0024','PPU0024',17,'Produto PPU0024',NULL,'Produto PPU0024 - PPU',15.53,40.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-03-16 13:50:25',1,4,NULL,0,1),
(133,'PPU0025','PPU0025',4,'Produto PPU0025',NULL,'Produto PPU0025 - PPU',19.41,50.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:00:19',1,4,NULL,0,1),
(134,'PPU0026','PPU0026',17,'Produto PPU0026',NULL,'Produto PPU0026 - PPU',36.24,90.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:01:30',1,4,NULL,0,1),
(135,'PPU0027','PPU0027',17,'Produto PPU0027',NULL,'Produto PPU0027 - PPU',33.65,85.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:01:38',1,4,NULL,0,1),
(136,'PVO0001','PVO0001',3,'Produto PVO0001',NULL,'Produto PVO0001 - PVO',0.00,200.00,23.00,0,NULL,0,0.000,1,'g','','PVO','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-16 12:52:09',1,4,NULL,0,1),
(137,'PPU0000','PPU0000',4,'Produto PPU0000',NULL,'Produto PPU0000 - PPU',38.83,95.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(138,'PPU0028','PPU0028',4,'Produto PPU0028',NULL,'Produto PPU0028 - PPU',0.00,140.00,23.00,0,NULL,0,36.000,1,'g','21','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:00:33',1,4,NULL,0,1),
(139,'PPU0029','PPU0029',4,'Produto PPU0029',NULL,'Produto PPU0029 - PPU',0.00,140.00,23.00,0,NULL,0,34.000,1,'g','20.5','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:00:40',1,4,NULL,0,1),
(140,'PPU0030','PPU0030',4,'Produto PPU0030',NULL,'Produto PPU0030 - PPU',0.00,160.00,23.00,0,NULL,0,41.000,1,'g','19','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-16 12:54:55',1,4,NULL,0,1),
(141,'PPU0031','PPU0031',4,'Produto PPU0031',NULL,'Produto PPU0031 - PPU',0.00,170.00,23.00,1,NULL,0,43.000,1,'g','20','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-16 12:53:14',1,4,NULL,0,1),
(142,'PPU0032','PPU0032',4,'Produto PPU0032',NULL,'Produto PPU0032 - PPU',0.00,170.00,23.00,0,NULL,0,45.000,1,'g','20','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(143,'PPU0033','PPU0033',4,'Produto PPU0033',NULL,'Produto PPU0033 - PPU',0.00,170.00,23.00,0,NULL,0,45.000,1,'g','21','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:01:00',1,4,NULL,0,1),
(144,'PPU0034','PPU0034',4,'Produto PPU0034',NULL,'Produto PPU0034 - PPU',0.00,170.00,23.00,1,NULL,0,46.000,1,'g','21.5','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(145,'PPU0035','PPU0035',4,'Produto PPU0035',NULL,'Produto PPU0035 - PPU',0.00,175.00,23.00,1,NULL,0,46.000,1,'g','20.5','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(146,'PPU0036','PPU0036',4,'Produto PPU0036',NULL,'Produto PPU0036 - PPU',0.00,20.00,23.00,2,NULL,0,45752.000,1,'g','19','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(147,'PPU0037','PPU0037',4,'Produto PPU0037',NULL,'Produto PPU0037 - PPU',0.00,225.00,23.00,0,NULL,0,60.000,1,'g','21','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(148,'PPU0038','PPU0038',4,'Produto PPU0038',NULL,'Produto PPU0038 - PPU',0.00,235.00,23.00,0,NULL,0,62.000,1,'g','20','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-16 12:55:22',1,4,NULL,0,1),
(149,'PPU0039','PPU0039',4,'Produto PPU0039',NULL,'Produto PPU0039 - PPU',0.00,25.00,23.00,0,NULL,0,6.000,1,'g','20','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(150,'PPU0040','PPU0040',4,'Produto PPU0040',NULL,'Produto PPU0040 - PPU',0.00,25.00,23.00,1,NULL,0,7.000,1,'g','18','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(151,'PPU0041','PPU0041',4,'Produto PPU0041',NULL,'Produto PPU0041 - PPU',0.00,35.00,23.00,2,NULL,0,8.000,1,'g','18','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(152,'PPU0042','PPU0042',4,'Produto PPU0042',NULL,'Produto PPU0042 - PPU',0.00,35.00,23.00,1,NULL,0,8.000,1,'g','20','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(153,'PPU0043','PPU0043',17,'Produto PPU0043',NULL,'Produto PPU0043 - PPU',0.00,40.00,23.00,1,NULL,0,10.000,1,'g','19','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:01:44',1,4,NULL,0,1),
(154,'PPU0044','PPU0044',17,'Produto PPU0044',NULL,'Produto PPU0044 - PPU',0.00,40.00,23.00,1,NULL,0,10.000,1,'g','20','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:01:52',1,4,NULL,0,1),
(155,'PPU0045','PPU0045',17,'Produto PPU0045',NULL,'Produto PPU0045 - PPU',0.00,40.00,23.00,1,NULL,0,10.000,1,'g','20','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:01:59',1,4,NULL,0,1),
(156,'PPU0046','PPU0046',4,'Produto PPU0046',NULL,'Produto PPU0046 - PPU',0.00,40.00,23.00,0,NULL,0,10.000,1,'g','22','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(157,'PPU0047','PPU0047',4,'Produto PPU0047',NULL,'Produto PPU0047 - PPU',0.00,40.00,23.00,1,NULL,0,9.000,1,'g','17','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(158,'PPU0048','PPU0048',17,'Produto PPU0048',NULL,'Produto PPU0048 - PPU',0.00,40.00,23.00,1,NULL,0,9.000,1,'g','20','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:02:06',1,4,NULL,0,1),
(159,'PPU0049','PPU0049',4,'Produto PPU0049',NULL,'Produto PPU0049 - PPU',0.00,40.00,23.00,1,NULL,0,9.000,1,'g','20','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(160,'PPU0050','PPU0050',4,'Produto PPU0050',NULL,'Produto PPU0050 - PPU',0.00,40.00,23.00,1,NULL,0,9.000,1,'g','20','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(161,'PPU0051','PPU0051',4,'Produto PPU0051',NULL,'Produto PPU0051 - PPU',0.00,40.00,23.00,0,NULL,0,12.000,1,'g','18.5','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(162,'PPU0052','PPU0052',4,'Produto PPU0052',NULL,'Produto PPU0052 - PPU',0.00,50.00,23.00,1,NULL,0,12.000,1,'g','19','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(163,'PPU0053','PPU0053',17,'Produto PPU0053',NULL,'Produto PPU0053 - PPU',0.00,50.00,23.00,1,NULL,0,12.000,1,'g','20','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:02:14',1,4,NULL,0,1),
(164,'PPU0054','PPU0054',4,'Produto PPU0054',NULL,'Produto PPU0054 - PPU',0.00,40.00,23.00,1,NULL,0,13.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(165,'PPU0055','PPU0055',17,'Produto PPU0055',NULL,'Produto PPU0055 - PPU',0.00,50.00,23.00,1,NULL,0,13.000,1,'g','19','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:02:22',1,4,NULL,0,1),
(166,'PPU0056','PPU0056',17,'Produto PPU0056',NULL,'Produto PPU0056 - PPU',0.00,50.00,23.00,1,NULL,0,13.000,1,'g','20','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:03:42',1,4,NULL,0,1),
(167,'PPU0057','PPU0057',17,'Produto PPU0057',NULL,'Produto PPU0057 - PPU',0.00,50.00,23.00,1,NULL,0,13.000,1,'g','22','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:03:47',1,4,NULL,0,1),
(168,'PPU0058','PPU0058',4,'Produto PPU0058',NULL,'Produto PPU0058 - PPU',0.00,120.00,23.00,0,NULL,0,29.000,1,'g','20.5','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:02:06',1,4,NULL,0,1),
(169,'PPU0059','PPU0059',4,'Produto PPU0059',NULL,'Produto PPU0059 - PPU',0.00,50.00,23.00,0,NULL,0,0.000,1,'g','19','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:01:58',1,4,NULL,0,1),
(170,'PPU0060','PPU0060',4,'Produto PPU0060',NULL,'Produto PPU0060 - PPU',0.00,100.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(171,'PPU0061','PPU0061',4,'Produto PPU0061',NULL,'Produto PPU0061 - PPU',0.00,75.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(172,'PPU0062','PPU0062',17,'Produto PPU0062',NULL,'Produto PPU0062 - PPU',0.00,50.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:03:54',1,4,NULL,0,1),
(173,'PPU0063','PPU0063',4,'Produto PPU0063',NULL,'Produto PPU0063 - PPU',0.00,75.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,0,1),
(174,'PPU0064','PPU0064',17,'Produto PPU0064',NULL,'Produto PPU0064 - PPU',0.00,75.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 16:04:01',1,4,NULL,0,1),
(175,'PPU0065','PPU0065',4,'Produto PPU0065',NULL,'Produto PPU0065 - PPU',0.00,35.00,23.00,0,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2026-01-08 13:02:39',1,4,NULL,0,1),
(176,'PPU0066','PPU0066',4,'Produto PPU0066',NULL,'Produto PPU0066 - PPU',0.00,75.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,1,1),
(177,'PPU0067','PPU0067',19,'Produto PPU0067',NULL,'Produto PPU0067 - PPU',0.00,20.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:51:45',1,4,NULL,0,1),
(178,'PPU0068','PPU0068',19,'Produto PPU0068',NULL,'Produto PPU0068 - PPU',0.00,20.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:45:56',1,4,NULL,1,1),
(179,'PPU0069','PPU0069',19,'Produto PPU0069',NULL,'Produto PPU0069 - PPU',0.00,15.00,23.00,2,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:52:59',1,4,NULL,0,1),
(180,'PPU0070','PPU0070',19,'Produto PPU0070',NULL,'Produto PPU0070 - PPU',0.00,15.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:49:44',1,4,NULL,1,1),
(181,'PPU0071','PPU0071',19,'Produto PPU0071',NULL,'Produto PPU0071 - PPU',0.00,15.00,23.00,1,NULL,0,0.000,1,'g','','PPU','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:53:05',1,4,NULL,0,1),
(182,'PVO0002','PVO0002',3,'Produto PVO0002',NULL,'Produto PVO0002 - PVO',0.00,190.00,23.00,0,NULL,0,0.000,1,'g','','PVO','Prata 925',NULL,NULL,NULL,1,0,0,'','2025-05-22 14:56:57','2025-12-19 16:02:41',1,1,NULL,1,1),
(183,'PVO0003','PVO0003',18,'Produto PVO0003',NULL,'Produto PVO0003 - PVO',0.00,40.00,23.00,1,NULL,0,0.000,1,'g','','PVO','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:56:31',1,4,NULL,0,1),
(184,'PVO0004','PVO0004',18,'Produto PVO0004',NULL,'Produto PVO0004 - PVO',0.00,40.00,23.00,2,NULL,0,0.000,1,'g','','PVO','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:50:12',1,4,NULL,1,1),
(185,'PVO0005','PVO0005',18,'Produto PVO0005',NULL,'Produto PVO0005 - PVO',0.00,40.00,23.00,1,NULL,0,0.000,1,'g','','PVO','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:50:59',1,4,NULL,1,1),
(186,'PVO0006','PVO0006',18,'Produto PVO0006',NULL,'Produto PVO0006 - PVO',0.00,20.00,23.00,1,NULL,0,0.000,1,'g','','PVO','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:56:47',1,4,NULL,0,1),
(187,'PVO0007','PVO0007',18,'Produto PVO0007',NULL,'Produto PVO0007 - PVO',0.00,20.00,23.00,2,NULL,0,0.000,1,'g','','PVO','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-02-19 15:57:00',1,4,NULL,0,1),
(188,'PVO0008','PVO0008',18,'Produto PVO0008',NULL,'Produto PVO0008 - PVO',0.00,40.00,23.00,0,NULL,0,0.000,1,'g','','PVO','Prata 925','','','[]',1,0,0,'','2025-05-22 14:56:57','2026-03-17 18:42:41',1,4,NULL,0,1),
(193,'MCCL0001',NULL,13,'Produto 1771518775080',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:32:55',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:32:55','2026-02-19 20:30:11',4,4,NULL,0,1),
(194,'MCCL0002',NULL,13,'Produto 1771518791653',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:33:11',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:33:11','2026-02-19 20:30:11',4,4,NULL,0,1),
(195,'MCCL0003',NULL,13,'Produto 1771518801981',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:33:21',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:33:21','2026-02-19 20:30:11',4,4,NULL,0,1),
(196,'MCCL0004','',13,'Produto 1771519590164',NULL,'',0.00,35.00,23.00,2,'2026-02-19 16:46:30',0,0.000,1,'g','','','','','','[]',1,0,0,NULL,'2026-02-19 16:46:30','2026-02-19 20:30:11',4,4,NULL,0,1),
(197,'MCCL0005',NULL,13,'Produto 1771519599576',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:46:39',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:46:39','2026-02-19 20:30:11',4,4,NULL,0,1),
(198,'MCCL0006',NULL,13,'Produto 1771519694697',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:48:14',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:48:14','2026-02-19 20:30:11',4,4,NULL,0,1),
(199,'MCCL0007',NULL,13,'Produto 1771519701571',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:48:21',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:48:21','2026-02-19 20:30:11',4,4,NULL,0,1),
(200,'MCCL0008',NULL,13,'Produto 1771519709675',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:48:29',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:48:29','2026-02-19 20:30:11',4,4,NULL,0,1),
(201,'MCCL0009',NULL,13,'Produto 1771519716244',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:48:36',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:48:36','2026-02-19 20:30:11',4,4,NULL,0,1),
(202,'MCB0001',NULL,14,'Produto 1771519751251',NULL,NULL,0.00,30.00,23.00,2,'2026-02-19 16:49:11',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:49:11','2026-02-19 20:30:11',4,4,NULL,0,1),
(203,'LTPD0001',NULL,11,'Produto 1771519859080',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 16:50:59',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:50:59','2026-02-19 20:30:11',4,4,NULL,0,1),
(204,'LTPD0002',NULL,11,'Produto 1771519865020',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 16:51:05',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:51:05','2026-02-19 20:30:11',4,4,NULL,0,1),
(205,'LTPD0003','',11,'Produto 1771519879571',NULL,'',0.00,20.00,23.00,2,'2026-02-19 16:51:19',0,0.000,1,'g','','','','','','[]',1,0,0,NULL,'2026-02-19 16:51:19','2026-02-19 20:30:11',4,4,NULL,0,1),
(206,'LTPD0004','',11,'Produto 1771519886525',NULL,'',0.00,20.00,23.00,2,'2026-02-19 16:51:26',0,0.000,1,'g','','','','','','[]',1,0,0,NULL,'2026-02-19 16:51:26','2026-02-19 20:30:11',4,4,NULL,0,1),
(207,'LTPD0005',NULL,11,'Produto 1771519892102',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 16:51:32',0,0.000,1,'g',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,'2026-02-19 16:51:32','2026-02-19 20:30:11',4,4,NULL,0,1),
(208,'LTA0001','',9,'Produto 1771522200984',NULL,'',0.00,20.00,23.00,1,'2026-02-19 17:30:00',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 17:30:00','2026-02-19 20:30:11',4,4,NULL,0,1),
(209,'LTA0002',NULL,9,'Produto 1771522217768',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 17:30:17',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 17:30:17','2026-02-19 20:30:11',4,4,NULL,0,1),
(210,'LTA0003',NULL,9,'Produto 1771522275400',NULL,NULL,0.00,15.00,23.00,1,'2026-02-19 17:31:15',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 17:31:15','2026-02-19 20:30:11',4,4,NULL,0,1),
(211,'LTA0004',NULL,9,'Produto 1771522294487',NULL,NULL,0.00,20.00,23.00,2,'2026-02-19 17:31:34',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 17:31:34','2026-02-19 20:30:11',4,4,NULL,0,1),
(212,'LTA0005',NULL,9,'Produto 1771522356566',NULL,NULL,0.00,15.00,23.00,2,'2026-02-19 17:32:36',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 17:32:36','2026-02-19 20:30:11',4,4,NULL,0,1),
(213,'LTA0006','',9,'Produto 1771522382155',NULL,'',0.00,10.00,23.00,3,'2026-02-19 17:33:02',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 17:33:02','2026-03-31 13:40:38',4,4,NULL,0,1),
(214,'LTA0007','',9,'Produto 1771522402559',NULL,'',0.00,10.00,23.00,1,'2026-02-19 17:33:22',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 17:33:22','2026-03-31 13:42:21',4,4,NULL,0,1),
(215,'LTA0008',NULL,9,'Produto 1771522463233',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 17:34:23',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 17:34:23','2026-02-19 20:30:11',4,4,NULL,0,1),
(216,'LTA0009',NULL,9,'Produto 1771522503664',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 17:35:03',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 17:35:03','2026-02-19 20:30:11',4,4,NULL,0,1),
(217,'LTA0010',NULL,9,'Produto 1771522607558',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 17:36:47',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 17:36:47','2026-02-19 20:30:11',4,4,NULL,0,1),
(218,'LTA0011',NULL,9,'Produto 1771522863227',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 17:41:03',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 17:41:03','2026-02-19 20:30:11',4,4,NULL,0,1),
(219,'LTA0012',NULL,9,'Produto 1771523214988',NULL,NULL,0.00,25.00,23.00,4,'2026-02-19 17:46:54',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 17:46:54','2026-02-19 20:30:11',4,4,NULL,0,1),
(220,'LTA0013',NULL,9,'Produto 1771523248195',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 17:47:28',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 17:47:28','2026-02-19 20:30:11',4,4,NULL,0,1),
(221,'LTA0014',NULL,9,'Produto 1771523290217',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 17:48:10',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 17:48:10','2026-02-19 20:30:11',4,4,NULL,0,1),
(222,'LTA0015','',9,'Produto 1771523313504',NULL,'',0.00,30.00,23.00,1,'2026-02-19 17:48:33',0,0.000,1,'g','','','','Dourado','','[]',1,0,0,NULL,'2026-02-19 17:48:33','2026-03-31 13:42:52',4,4,NULL,0,1),
(223,'LTA0016',NULL,9,'Produto 1771523350076',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 17:49:10',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 17:49:10','2026-02-19 20:30:11',4,4,NULL,0,1),
(224,'LTA0017',NULL,9,'Produto 1771523390827',NULL,NULL,0.00,15.00,23.00,2,'2026-02-19 17:49:50',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 17:49:50','2026-02-19 20:30:11',4,4,NULL,0,1),
(225,'LTA0018',NULL,9,'Produto 1771523612874',NULL,NULL,0.00,15.00,23.00,2,'2026-02-19 17:53:32',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 17:53:32','2026-02-19 20:30:11',4,4,NULL,0,1),
(226,'LTA0019',NULL,9,'Produto 1771526240022',NULL,NULL,0.00,15.00,23.00,2,'2026-02-19 18:37:20',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 18:37:20','2026-02-19 20:30:11',4,4,NULL,0,1),
(227,'LTA0020','',9,'Produto 1771526465484',NULL,'',0.00,30.00,23.00,4,'2026-02-19 18:41:05',0,0.000,1,'g','','','','Dourado','','[]',1,0,0,NULL,'2026-02-19 18:41:05','2026-02-19 20:48:36',4,4,NULL,0,1),
(228,'LTA0021',NULL,9,'Produto 1771527725962',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:02:05',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:02:05','2026-02-19 20:30:11',4,4,NULL,0,1),
(229,'LTA0022',NULL,9,'Produto 1771528022391',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:07:02',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:07:02','2026-02-19 20:30:11',4,4,NULL,0,1),
(230,'LTA0023',NULL,9,'Produto 1771528032649',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:07:12',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:07:12','2026-02-19 20:30:11',4,4,NULL,0,1),
(231,'LTA0024',NULL,9,'Produto 1771528073583',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:07:53',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:07:53','2026-02-19 20:30:11',4,4,NULL,0,1),
(232,'LTA0025',NULL,9,'Produto 1771528090008',NULL,NULL,0.00,15.00,23.00,1,'2026-02-19 19:08:10',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:08:10','2026-02-19 20:30:11',4,4,NULL,0,1),
(233,'LTA0026',NULL,9,'Produto 1771528116838',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:08:36',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:08:36','2026-02-19 20:30:11',4,4,NULL,0,1),
(234,'LTA0027',NULL,9,'Produto 1771528158646',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:09:18',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:09:18','2026-02-19 20:30:11',4,4,NULL,0,1),
(235,'LTA0028',NULL,9,'Produto 1771528232358',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:10:32',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:10:32','2026-02-19 20:30:11',4,4,NULL,0,1),
(236,'LTA0029',NULL,9,'Produto 1771528243408',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:10:43',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:10:43','2026-02-19 20:30:11',4,4,NULL,0,1),
(237,'LTA0030','',9,'Produto 1771528263193',NULL,'',0.00,25.00,23.00,2,'2026-02-19 19:11:03',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 19:11:03','2026-02-19 20:30:11',4,4,NULL,0,1),
(238,'LTA0031',NULL,9,'Produto 1771528279022',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:11:19',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:11:19','2026-02-19 20:30:11',4,4,NULL,0,1),
(239,'LTA0032',NULL,9,'Produto 1771528484575',NULL,NULL,0.00,25.00,23.00,1,'2026-02-19 19:14:44',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:14:44','2026-02-19 20:30:11',4,4,NULL,0,1),
(240,'LTA0033',NULL,9,'Produto 1771528531705',NULL,NULL,0.00,30.00,23.00,2,'2026-02-19 19:15:31',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:15:31','2026-02-19 20:30:11',4,4,NULL,0,1),
(241,'LTA0034','',9,'Produto 1771528551149',NULL,'',0.00,30.00,23.00,1,'2026-02-19 19:15:51',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 19:15:51','2026-02-21 11:11:38',4,4,NULL,0,1),
(242,'LTA0035',NULL,9,'Produto 1771528574771',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:16:14',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:16:14','2026-02-19 20:30:11',4,4,NULL,0,1),
(243,'LTA0036',NULL,9,'Produto 1771528591318',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:16:31',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:16:31','2026-02-19 20:30:11',4,4,NULL,0,1),
(244,'LTA0037',NULL,9,'Produto 1771528598390',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:16:38',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:16:38','2026-02-19 20:30:11',4,4,NULL,0,1),
(245,'LTA0038',NULL,9,'Produto 1771528627141',NULL,NULL,0.00,15.00,23.00,1,'2026-02-19 19:17:07',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:17:07','2026-02-19 20:30:11',4,4,NULL,0,1),
(246,'LTB0001',NULL,15,'Produto 1771530831375',NULL,NULL,0.00,35.00,23.00,1,'2026-02-19 19:53:51',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 19:53:51','2026-02-19 20:30:11',4,4,NULL,0,1),
(247,'LTB0002',NULL,15,'Produto 1771530851980',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:54:11',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 19:54:11','2026-02-19 20:30:11',4,4,NULL,0,1),
(248,'LTB0003','',15,'Produto 1771530904475',NULL,'',0.00,30.00,23.00,2,'2026-02-19 19:55:04',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 19:55:04','2026-02-19 20:30:11',4,4,NULL,0,1),
(249,'LTB0004',NULL,15,'Produto 1771530923930',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:55:23',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:55:23','2026-02-19 20:30:11',4,4,NULL,0,1),
(250,'LTB0005',NULL,15,'Produto 1771531004349',NULL,NULL,0.00,25.00,23.00,1,'2026-02-19 19:56:44',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:56:44','2026-02-19 20:30:11',4,4,NULL,0,1),
(251,'LTB0006',NULL,15,'Produto 1771531042838',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 19:57:22',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:57:22','2026-02-19 20:30:11',4,4,NULL,0,1),
(252,'LTB0007',NULL,15,'Produto 1771531076155',NULL,NULL,0.00,15.00,23.00,1,'2026-02-19 19:57:56',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:57:56','2026-02-19 20:30:11',4,4,NULL,0,1),
(253,'LTB0008',NULL,15,'Produto 1771531144307',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 19:59:04',0,0.000,1,'g',NULL,NULL,NULL,'Bronze',NULL,NULL,1,0,0,NULL,'2026-02-19 19:59:04','2026-02-19 20:30:11',4,4,NULL,0,1),
(254,'LTB0009',NULL,15,'Produto 1771531158845',NULL,NULL,0.00,25.00,23.00,2,'2026-02-19 19:59:18',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 19:59:18','2026-02-19 20:30:11',4,4,NULL,0,1),
(255,'LTB0010','',15,'Produto 1771531176199',NULL,'',0.00,25.00,23.00,2,'2026-02-19 19:59:36',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 19:59:36','2026-02-19 20:30:11',4,4,NULL,0,1),
(256,'LTB0011',NULL,15,'Produto 1771531234519',NULL,NULL,0.00,25.00,23.00,1,'2026-02-19 20:00:34',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 20:00:34','2026-02-19 20:30:11',4,4,NULL,0,1),
(257,'LTB0012','',15,'Produto 1771531245189',NULL,'',0.00,25.00,23.00,2,'2026-02-19 20:00:45',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 20:00:45','2026-02-19 20:30:11',4,4,NULL,0,1),
(258,'LTB0013',NULL,15,'Produto 1771531279013',NULL,NULL,0.00,25.00,23.00,2,'2026-02-19 20:01:19',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 20:01:19','2026-02-19 20:30:11',4,4,NULL,0,1),
(259,'LTB0014',NULL,15,'Produto 1771531292177',NULL,NULL,0.00,25.00,23.00,1,'2026-02-19 20:01:32',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 20:01:32','2026-02-19 20:30:11',4,4,NULL,0,1),
(260,'LTB0015','',15,'Produto 1771531300403',NULL,'',0.00,25.00,23.00,1,'2026-02-19 20:01:40',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 20:01:40','2026-02-19 20:30:11',4,4,NULL,0,1),
(261,'LTB0016',NULL,15,'Produto 1771531322676',NULL,NULL,0.00,25.00,23.00,1,'2026-02-19 20:02:02',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 20:02:02','2026-02-19 20:30:11',4,4,NULL,0,1),
(262,'LTB0017',NULL,15,'Produto 1771531539360',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 20:05:39',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:05:39','2026-02-19 20:30:11',4,4,NULL,0,1),
(263,'LTB0018',NULL,15,'Produto 1771531551312',NULL,NULL,0.00,20.00,23.00,2,'2026-02-19 20:05:51',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:05:51','2026-02-19 20:30:11',4,4,NULL,0,1),
(264,'LTB0019','',15,'Produto 1771531564188',NULL,'',0.00,20.00,23.00,6,'2026-02-19 20:06:04',0,0.000,1,'g','','','','Dourado','','[]',1,0,0,NULL,'2026-02-19 20:06:04','2026-02-19 20:30:11',4,4,NULL,0,1),
(265,'LTB0020',NULL,15,'Produto 1771531602386',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 20:06:42',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:06:42','2026-02-19 20:30:11',4,4,NULL,0,1),
(266,'LTB0021',NULL,15,'Produto 1771531634177',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 20:07:14',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:07:14','2026-02-19 20:30:11',4,4,NULL,0,1),
(267,'LTB0022',NULL,15,'Produto 1771531650901',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 20:07:30',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:07:30','2026-02-19 20:30:11',4,4,NULL,0,1),
(268,'LTB0023',NULL,15,'Produto 1771531703474',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 20:08:23',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:08:23','2026-02-19 20:30:11',4,4,NULL,0,1),
(269,'LTB0024',NULL,15,'Produto 1771531719301',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 20:08:39',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:08:39','2026-02-19 20:30:11',4,4,NULL,0,1),
(270,'LTB0025',NULL,15,'Produto 1771531787770',NULL,NULL,0.00,15.00,23.00,1,'2026-02-19 20:09:47',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 20:09:47','2026-02-19 20:30:11',4,4,NULL,0,1),
(271,'LTB0026',NULL,15,'Produto 1771531955738',NULL,NULL,0.00,10.00,23.00,1,'2026-02-19 20:12:35',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:12:35','2026-02-19 20:30:11',4,4,NULL,0,1),
(272,'LTB0027',NULL,15,'Produto 1771532721535',NULL,NULL,0.00,20.00,23.00,2,'2026-02-19 20:25:21',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:25:21','2026-02-19 20:30:11',4,4,NULL,0,1),
(273,'LTB0028',NULL,15,'Produto 1771532730184',NULL,NULL,0.00,20.00,23.00,1,'2026-02-19 20:25:30',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:25:30','2026-02-19 20:30:11',4,4,NULL,0,1),
(274,'LTPC0001',NULL,22,'Produto 1771534238760',NULL,NULL,0.00,25.00,23.00,1,'2026-02-19 20:50:38',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:50:38','2026-03-05 00:28:58',4,4,NULL,0,1),
(275,'LTPC0002',NULL,22,'Produto 1771534246373',NULL,NULL,0.00,25.00,23.00,1,'2026-02-19 20:50:46',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-19 20:50:46','2026-03-05 00:28:58',4,4,NULL,0,1),
(276,'LTPC0003',NULL,22,'Produto 1771534264483',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 20:51:04',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 20:51:04','2026-03-05 00:28:58',4,4,NULL,0,1),
(277,'LTPC0004',NULL,22,'Produto 1771534272013',NULL,NULL,0.00,30.00,23.00,1,'2026-02-19 20:51:12',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-02-19 20:51:12','2026-03-05 00:28:58',4,4,NULL,0,1),
(278,'LTPC0005','',22,'Produto 1771534282473',NULL,'',0.00,30.00,23.00,0,'2026-02-19 20:51:22',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-02-19 20:51:22','2026-05-04 16:11:49',4,4,NULL,0,1),
(279,'PNC0001','',18,'Produto 1771692714454',NULL,'',0.00,25.00,23.00,1,'2026-02-21 16:51:54',0,0.000,1,'g','','','','Dourado','','[]',1,0,0,NULL,'2026-02-21 16:51:54','2026-02-21 16:52:35',4,4,NULL,0,1),
(280,'LTPR0001',NULL,23,'Produto 1771693772053',NULL,NULL,0.00,5.00,23.00,1,'2026-02-21 17:09:32',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-21 17:09:32','2026-03-05 00:28:58',4,4,NULL,0,1),
(281,'LTPR0002',NULL,23,'Produto 1771693785157',NULL,NULL,0.00,5.00,23.00,1,'2026-02-21 17:09:45',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-21 17:09:45','2026-03-05 00:28:58',4,4,NULL,0,1),
(282,'LTPR0003',NULL,23,'Produto 1771693828938',NULL,NULL,0.00,5.00,23.00,1,'2026-02-21 17:10:28',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-21 17:10:28','2026-03-05 00:28:58',4,4,NULL,0,1),
(283,'LTPR0004',NULL,23,'Produto 1771693837979',NULL,NULL,0.00,5.00,23.00,1,'2026-02-21 17:10:37',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-21 17:10:37','2026-03-05 00:28:58',4,4,NULL,0,1),
(284,'LTPR0005',NULL,23,'Produto 1771693847158',NULL,NULL,0.00,5.00,23.00,1,'2026-02-21 17:10:47',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-21 17:10:47','2026-03-05 00:28:58',4,4,NULL,0,1),
(285,'LTPRS0001','',24,'Produto 1771693855310',NULL,'',0.00,5.00,23.00,1,'2026-02-21 17:10:55',0,0.000,1,'g','','','','Dourado','','[]',1,0,0,NULL,'2026-02-21 17:10:55','2026-03-05 00:22:02',4,4,NULL,0,1),
(286,'LTPRS0002',NULL,24,'Produto 1771693893040',NULL,NULL,0.00,5.00,23.00,1,'2026-02-21 17:11:33',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-02-21 17:11:33','2026-03-05 00:28:58',4,4,NULL,0,1),
(287,'PVO0009','',3,'Colar de Prata com Malha Bizantina',NULL,'',0.00,175.00,23.00,1,'2026-03-18 19:18:18',0,0.000,1,'g','','','','','','[]',1,0,0,NULL,'2026-03-18 19:18:18','2026-03-18 19:53:46',4,4,NULL,0,1),
(288,'PVO0010','',3,'Colar de Prata com Malha Bali Trançada',NULL,'',0.00,85.00,23.00,1,'2026-03-18 19:33:56',0,0.000,1,'g','','','','','','[]',1,0,0,NULL,'2026-03-18 19:33:56','2026-03-18 19:54:07',4,4,NULL,0,1),
(289,'PVO0011','',3,'Colar de Prata com Malha Escama',NULL,'',0.00,130.00,23.00,1,'2026-03-18 19:43:04',0,0.000,1,'g','','','','','','[]',1,0,0,NULL,'2026-03-18 19:43:04','2026-03-18 19:53:27',4,4,NULL,0,1),
(290,'PVO0012','',3,'Colar de Prata com Malha Escama Dupla - 62cm/4mm',NULL,'Tamanho:\r\nComprimento - 62cm\r\nDiametro - 4mm',0.00,170.00,23.00,1,'2026-03-18 19:51:40',0,0.000,1,'g','','','','','','[]',1,0,0,NULL,'2026-03-18 19:51:40','2026-03-18 19:54:27',4,4,NULL,0,1),
(291,'PVO0013','',3,'Colar de Prata com Malha Escama Dupla - 56cm/6mm',NULL,'Tamanho:\r\nComprimento - 56cm\r\nDiametro - 6mm',0.00,220.00,23.00,1,'2026-03-18 19:52:24',0,0.000,1,'g','','','','','','[]',1,0,0,NULL,'2026-03-18 19:52:24','2026-03-18 19:53:09',4,4,NULL,0,1),
(292,'LTCU0001',NULL,8,'Produto 1774966090607',NULL,NULL,0.00,20.00,23.00,1,'2026-03-31 14:08:10',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-03-31 14:08:10','2026-04-01 01:40:02',4,4,NULL,0,1),
(293,'LTCU0002',NULL,8,'Produto 1774966136333',NULL,NULL,0.00,25.00,23.00,1,'2026-03-31 14:08:56',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-03-31 14:08:56','2026-04-01 01:40:02',4,4,NULL,0,1),
(294,'LTCU0003',NULL,8,'Produto 1774966151919',NULL,NULL,0.00,20.00,23.00,1,'2026-03-31 14:09:11',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-03-31 14:09:11','2026-04-01 01:40:02',4,4,NULL,0,1),
(295,'LTP0001',NULL,25,'Produto 1774966376769',NULL,NULL,0.00,20.00,23.00,1,'2026-03-31 14:12:56',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-03-31 14:12:56','2026-04-01 01:40:02',4,4,NULL,0,1),
(296,'LTCU0004',NULL,8,'Produto 1774966510332',NULL,NULL,0.00,30.00,23.00,2,'2026-03-31 14:15:10',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-03-31 14:15:10','2026-04-01 01:40:02',4,4,NULL,0,1),
(297,'LTCU0005',NULL,8,'Produto 1774966557996',NULL,NULL,0.00,35.00,23.00,2,'2026-03-31 14:15:57',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-03-31 14:15:57','2026-04-01 01:40:02',4,4,NULL,0,1),
(298,'LTCU0006',NULL,8,'Produto 1774966591373',NULL,NULL,0.00,35.00,23.00,1,'2026-03-31 14:16:31',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-03-31 14:16:31','2026-04-01 01:40:02',4,4,NULL,0,1),
(299,'LTCU0007',NULL,8,'Produto 1774966627329',NULL,NULL,0.00,30.00,23.00,2,'2026-03-31 14:17:07',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-03-31 14:17:07','2026-04-01 01:40:02',4,4,NULL,0,1),
(301,'LTCU0009',NULL,8,'Produto 1774966769404',NULL,NULL,0.00,25.00,23.00,1,'2026-03-31 14:19:29',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-03-31 14:19:29','2026-04-01 01:40:02',4,4,NULL,0,1),
(303,'LTCU0010','',8,'Produto 1775000953204',NULL,'',0.00,20.00,23.00,2,'2026-03-31 23:49:13',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-03-31 23:49:13','2026-04-01 01:40:02',4,4,NULL,0,1),
(304,'LTCU0011',NULL,8,'Produto 1775001108791',NULL,NULL,0.00,25.00,23.00,3,'2026-03-31 23:51:48',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-03-31 23:51:48','2026-04-01 01:40:02',4,4,NULL,0,1),
(305,'LTCU0012',NULL,8,'Produto 1775001606115',NULL,NULL,0.00,25.00,23.00,2,'2026-04-01 00:00:06',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:00:06','2026-04-01 01:40:02',4,4,NULL,0,1),
(306,'LTCU0013',NULL,8,'Produto 1775002092697',NULL,NULL,0.00,25.00,23.00,1,'2026-04-01 00:08:12',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:08:12','2026-04-01 01:40:02',4,4,NULL,0,1),
(307,'LTCU0014',NULL,8,'Produto 1775002121084',NULL,NULL,0.00,30.00,23.00,2,'2026-04-01 00:08:41',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:08:41','2026-04-01 01:40:02',4,4,NULL,0,1),
(308,'LTCU0015',NULL,8,'Produto 1775002141531',NULL,NULL,0.00,35.00,23.00,2,'2026-04-01 00:09:01',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:09:01','2026-04-01 01:40:02',4,4,NULL,0,1),
(309,'LTCU0016',NULL,8,'Produto 1775002186525',NULL,NULL,0.00,35.00,23.00,1,'2026-04-01 00:09:46',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:09:46','2026-04-01 01:40:02',4,4,NULL,0,1),
(310,'LTCU0017',NULL,8,'Produto 1775002210221',NULL,NULL,0.00,25.00,23.00,1,'2026-04-01 00:10:10',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-04-01 00:10:10','2026-04-01 01:40:02',4,4,NULL,0,1),
(311,'LTCU0018',NULL,8,'Produto 1775003358939',NULL,'Pedra rouxa',0.00,20.00,23.00,1,'2026-04-01 00:29:18',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-04-01 00:29:18','2026-04-01 01:40:02',4,4,NULL,0,1),
(312,'LTCU0019',NULL,8,'Produto 1775003376359',NULL,'pedra verde',0.00,20.00,23.00,1,'2026-04-01 00:29:36',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-04-01 00:29:36','2026-04-01 01:40:02',4,4,NULL,0,1),
(313,'LTCU0020',NULL,8,'Produto 1775003391802',NULL,'pedra da lua',0.00,20.00,23.00,1,'2026-04-01 00:29:51',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-04-01 00:29:51','2026-04-01 01:40:02',4,4,NULL,0,1),
(314,'LTCU0021',NULL,8,'Produto 1775003409016',NULL,NULL,0.00,30.00,23.00,1,'2026-04-01 00:30:09',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:30:09','2026-04-01 01:40:02',4,4,NULL,0,1),
(315,'LTCU0022',NULL,8,'Produto 1775004314704',NULL,NULL,0.00,30.00,23.00,2,'2026-04-01 00:45:14',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-04-01 00:45:14','2026-04-01 01:40:02',4,4,NULL,0,1),
(316,'LTCU0023',NULL,8,'Produto 1775004360685',NULL,'pedra da lua - labradorita',0.00,20.00,23.00,1,'2026-04-01 00:46:00',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-04-01 00:46:00','2026-04-01 01:40:02',4,4,NULL,0,1),
(317,'LTCU0024',NULL,8,'Produto 1775004378557',NULL,'Pedra Verde',0.00,20.00,23.00,1,'2026-04-01 00:46:18',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-04-01 00:46:18','2026-04-01 01:40:02',4,4,NULL,0,1),
(318,'LTCU0025',NULL,8,'Produto 1775004397967',NULL,NULL,0.00,25.00,23.00,2,'2026-04-01 00:46:37',0,0.000,1,'g',NULL,NULL,NULL,'Banho de Prata',NULL,NULL,1,0,0,NULL,'2026-04-01 00:46:37','2026-04-01 01:40:02',4,4,NULL,0,1),
(319,'LTG0001',NULL,7,'Produto 1775004520159',NULL,NULL,0.00,35.00,23.00,2,'2026-04-01 00:48:40',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:48:40','2026-04-01 01:40:02',4,4,NULL,0,1),
(320,'LTG0002',NULL,7,'Produto 1775004567431',NULL,NULL,0.00,35.00,23.00,1,'2026-04-01 00:49:27',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:49:27','2026-04-01 01:40:02',4,4,NULL,0,1),
(321,'LTG0003',NULL,7,'Produto 1775004633071',NULL,NULL,0.00,30.00,23.00,3,'2026-04-01 00:50:33',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 00:50:33','2026-04-01 01:40:02',4,4,NULL,0,1),
(322,'LTG0004',NULL,7,'Produto 1775006638455',NULL,NULL,0.00,30.00,23.00,4,'2026-04-01 01:23:58',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:23:58','2026-04-01 01:40:02',4,4,NULL,0,1),
(323,'LTG0005',NULL,7,'Produto 1775007159712',NULL,NULL,0.00,35.00,23.00,4,'2026-04-01 01:32:39',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:32:39','2026-04-01 01:40:02',4,4,NULL,0,1),
(324,'LTG0006',NULL,7,'Produto 1775007202655',NULL,NULL,0.00,30.00,23.00,3,'2026-04-01 01:33:22',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:33:22','2026-04-01 01:40:02',4,4,NULL,0,1),
(325,'LTG0007','',7,'Produto 1775007235904',NULL,'',0.00,40.00,23.00,2,'2026-04-01 01:33:55',0,0.000,1,'g','','','','Banho de Prata','','[]',1,0,0,NULL,'2026-04-01 01:33:55','2026-04-01 01:40:02',4,4,NULL,0,1),
(326,'LTG0008',NULL,7,'Produto 1775007277654',NULL,NULL,0.00,35.00,23.00,1,'2026-04-01 01:34:37',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:34:37','2026-04-01 01:40:02',4,4,NULL,0,1),
(327,'LTG0009',NULL,7,'Produto 1775007335855',NULL,NULL,0.00,25.00,23.00,1,'2026-04-01 01:35:35',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:35:35','2026-04-01 01:40:02',4,4,NULL,0,1),
(328,'LTG0010',NULL,7,'Produto 1775007342483',NULL,NULL,0.00,25.00,23.00,1,'2026-04-01 01:35:42',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:35:42','2026-04-01 01:40:02',4,4,NULL,0,1),
(329,'LTG0011',NULL,7,'Produto 1775007365605',NULL,NULL,0.00,35.00,23.00,4,'2026-04-01 01:36:05',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:36:05','2026-04-01 01:40:02',4,4,NULL,0,1),
(330,'LTG0012',NULL,7,'Produto 1775007419709',NULL,NULL,0.00,25.00,23.00,2,'2026-04-01 01:36:59',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:36:59','2026-04-01 01:40:02',4,4,NULL,0,1),
(331,'LTG0013',NULL,7,'Produto 1775007439589',NULL,NULL,0.00,25.00,23.00,4,'2026-04-01 01:37:19',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:37:19','2026-04-01 01:40:02',4,4,NULL,0,1),
(332,'LTG0014',NULL,7,'Produto 1775007490251',NULL,NULL,0.00,35.00,23.00,2,'2026-04-01 01:38:10',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:38:10','2026-04-01 01:40:02',4,4,NULL,0,1),
(333,'LTG0015','',2,'Produto 1775007506546',NULL,'',0.00,35.00,23.00,2,'2026-04-01 01:38:26',0,0.000,1,'g','','','','Dourado','','[]',1,0,0,NULL,'2026-04-01 01:38:26','2026-04-01 01:41:52',4,4,NULL,0,1),
(334,'LTG0016',NULL,7,'Produto 1775007514784',NULL,NULL,0.00,35.00,23.00,2,'2026-04-01 01:38:34',0,0.000,1,'g',NULL,NULL,NULL,'Dourado',NULL,NULL,1,0,0,NULL,'2026-04-01 01:38:34','2026-04-01 01:40:02',4,4,NULL,0,1);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `featured_carousel_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `catalog_page_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `hide_catalog_prices` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Hide prices in catalog, show price on request instead',
  `hide_out_of_stock` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Hide out of stock',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES
(1,1,1,0,1,'2025-06-01 14:08:28','2026-02-14 17:32:40');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `movement_type` enum('in','out','adjustment','transfer') NOT NULL,
  `quantity` int(11) NOT NULL,
  `balance_before` int(11) DEFAULT NULL,
  `balance_after` int(11) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL COMMENT 'Ref. documento ou operaÃ§Ã£o',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Administrador','admin@gonzagas.com','$2b$10$OpQSfinNzajl/Ze7RMsaV.jOD38f5YwpUI.aeFy6Wt7obObCxjA8a','admin','2025-05-22 16:42:08','2025-05-22 17:36:43'),
(3,'Gonzaga','g.art.shine@gmail.com','$2a$10$OijqGczPermKWYRxGS6JVe2VdHqSwyZfuI1U4oycWBYeAdt82tSnK','admin','2025-05-22 21:00:07','2026-03-19 15:18:21'),
(4,'Miguel Melo','miguelmelo70@gmail.com','$2a$10$SFS3XVyOhsMt7LJRdKeR8urH1dDnNmC6yrbaB8pLyW7DmmEgfxSC2','admin','2025-05-22 21:04:15','2026-02-12 17:39:12'),
(5,'Gonzaga','gonzaga@artnshine.pt','$2a$10$goRYOLkXUINjrAHNIYFoZuVp06S.k.sQpsEOgC3dN9XRuzOezja46','admin','2025-07-17 16:32:05','2025-07-17 16:32:05');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'artnshin_gonzagas_db'
--

--
-- Dumping routines for database 'artnshin_gonzagas_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-05-26 13:44:38
